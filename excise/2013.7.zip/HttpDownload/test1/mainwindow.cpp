#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QFile>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    down = new HttpDownload();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void MainWindow::on_pushButton_clicked()
{
    QUrl url("http://www.goojje.com/images/logo_big.jpg");
    QUrl url2("http://www.google.com.hk/intl/zh-CN/images/logo_cn.png");
    QUrl url3("http://www.google.com.hk/");
    QUrl url4("http://192.168.1.209:8081/sheenoa/pcClient/getVersion.do?system=windows");
    down->setDownloadTempFolder("aacc");
    down->download(url);
    //down->download(url2);
    //down->download(url3);
    //down->download(url4);
    //down.finishDownload();
    //down->finishDownload();
}

void MainWindow::on_pushButton_2_clicked()
{
    //http://192.168.1.209:8081/sheenoa/pcClient/getVersion.do?system=windows
    QUrl url("http://192.168.1.209:8081/sheenoa/pcClient/update/getVersion.do");
    //QUrl url("http://www.baidu.com/index.html");
    connect(down,SIGNAL(getHttpResponse(QString)),ui->textEdit,SLOT(setText(QString)));
    down->beginHttpRequest(url,"system=windows");
}


void MainWindow::on_pushButton_3_clicked()
{
    QDir dir;
    QString strDir = "./aa/";
    int idx = strDir.lastIndexOf("/");
    strDir = strDir.mid(0,idx);
    dir.mkpath(strDir);
    //dir.mkdir("aa");
}

void MainWindow::on_pushButton_4_clicked()
{
    down->backupFile("Makefile");
    down->backupFile("peng/test.txt");
}

void MainWindow::on_pushButton_5_clicked()
{
    down->restoreBackupFiles();
}

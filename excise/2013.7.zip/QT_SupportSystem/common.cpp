#include "common.h"

Common::Common()
{
}

bool Common:: LoadFromFile(QString filename,QString *out)
{
    QFile file(filename);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        *out = file.readAll();
        file.close();
        return true;
    }
    return false;
}

QString Common:: LoadFromFile(QString filename)
{
    QString result;
    QFile file(filename);
    if(file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        result = file.readAll();
        file.close();
        return result;
    }
    return "";
}
bool Common::SaveToFile(QString filename,QString content)
{
    QFile file(filename);
    if(file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(&file);
        out << content;
        file.flush();
        file.close();
        return true;
    }
    return false;
}

void Common::WriteDebug(QString string)
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    qDebug()<< str + "---" + string;
}

void Common::Sleep(unsigned int time)
{
    QWaitCondition wait;
    QMutex mutex;
    mutex.lock();
    wait.wait(&mutex,time);
    mutex.unlock();
}

bool Common::MkDir(QString path)
{
    QDir *dir = new QDir();
    QString cur;
    int offset=path.indexOf("/");
    while(offset>0)
    {
        cur = path.left(offset);
        dir->setPath(cur);
        if(dir->exists()==false)dir->mkdir(dir->absolutePath());
        offset = path.indexOf("/",offset+1);
    }
    dir->setPath(path);
    if(dir->exists()==false)dir->mkdir(dir->absolutePath());
    return true;
}
QString Common::RequestServer(QString serverAddress, QString data)
{
    QNetworkAccessManager *nam;
    nam = new QNetworkAccessManager();

    QUrl url(serverAddress);
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader,"application/x-www-form-urlencoded");
    req.setHeader(QNetworkRequest::ContentLengthHeader,data.length());

    QByteArray arr=data.toAscii();
    QNetworkReply *reply = nam->post(req,arr);
    QEventLoop eventLoop;

    QObject::connect(nam, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
    eventLoop.exec();       //block until finish
    WriteDebug("服务器返回数据：");

    if(reply->error()==QNetworkReply::NoError)
    {
        QTextCodec *codec=QTextCodec::codecForName("GBK");
        QByteArray bytes = reply->readAll();
        QString content = codec->toUnicode(bytes);
        WriteDebug("收到服务器数据：" + content);
        return content;
    }
    else
    {
        WriteDebug("向服务器POST数据出错！");
    }
    return "";
}


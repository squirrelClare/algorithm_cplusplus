#ifndef CDEBUGGER_H
#define CDEBUGGER_H
#include<QFile>
#include<QTextStream>
#include <QDateTime>


class Debugger
{
private:
    QFile file;
    QTextStream *out;
public:
    Debugger(QString filename);
    ~Debugger();

    void WriteMsg(QString msg);

};

#endif // CDEBUGGER_H

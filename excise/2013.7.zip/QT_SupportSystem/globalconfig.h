#ifndef GLOBALCONFIG_H
#define GLOBALCONFIG_H
#include <QString>
#include <QSettings>
#include <QDebug>
const QString const_GAButtton_SqlB = "SELECT id,title FROM et_category  WHERE parent_id=%s ";
const QString const_GAButtton_SqlLimit = "SELECT id,title FROM et_category  WHERE parent_id=%s limit %d,%d";
const QString const_GAButtton_SqlCount = "SELECT count(id) as buttoncount FROM et_category WHERE parent_id=%s ";
const QString const_GANotice_SqlCount = " SELECT count(*) as buttoncount FROM et_article WHERE category_id = %s ";
const QString const_GANotice_SqlLimit = " SELECT id,title,from_unixtime(put_time) as put_time FROM et_article WHERE category_id = %s  order by id limit %d,%d";
const QString const_GANotice_SqlContent = "SELECT content from et_article_detail where article_id=%s";

#ifdef DEBUG_VERSION
  const QString p_StoreNo ="pc711"; // easytoo在epaylinks的商户号
  const QString p_UnionPay_IP = "219.136.207.188";
  const QString p_UnionPay_port = "5111";
#else
  const QString p_StoreNo = "TGZYZT001"; // easytoo在epaylinks的商户号
  const QString p_UnionPay_IP = "219.136.207.190";
  const QString p_UnionPay_port = "52222";
#endif
  const QString p_NetMac = "001109F69C46"; // 终端授权码
  const int p_UnionPay_ComBaud = 9600;

class GlobalConfig
{
private:
    QString WebSrvAddr;
    QString TerminalID;
    QString FAreaID;
    int Union_ComPort;
    QString Union_TerminalID;
    QString Union_TerminalPassWord;
    QString Union_PaySerialNo;
    QString Union_PayBatchNo;
    QString ePayLinks_SerialNo;
    int Print_ComPort;

    QSettings *setting;
    QSettings *privateSetting;
    QSettings *posSetting;
public:
    QString CardNo;
    QString comsumfee;
    QString PayBatchNo;
    QString PaySerialNo;

public:
    GlobalConfig();
    QString Get_AreaID();
    QString Get_TerminalID();
    int Get_Union_ComPort();
    QString Get_Union_TerminalID();
    QString Get_Union_TerminalPassword();
    QString Get_Union_PaySerialNo();
    QString Get_Union_PayBatchNo();
    QString Get_ePayLinks_SerialNo();
    int Get_Print_ComPort();
    void Asc_Union_PaySerialNo();
    void Asc_Union_PaySerialNo_100();
    void Save_Union_PaySerialNo(QString PaySerialNo);
    void Asc_ePayLinks_SerialNo();
    QString GetWebSrvAddr();
};

#endif // GLOBALCONFIG_H

#ifndef PICTUREDOWNLOADER_H
#define PICTUREDOWNLOADER_H
#include <QString>
#include "json.h"
#include "machineinfo.h"
#include "database.h"
#include "debugger.h"
#include "tradebase.h"
#include "common.h"

class PictureDownloader : public TradeBase
{
public:
    PictureDownloader(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString DownPicture(Json *json);
    QString GetRunTimeInfo(Json *json);
    QString GetFlexFunInfoFromServer();
};

#endif // PICTUREDOWNLOADER_H

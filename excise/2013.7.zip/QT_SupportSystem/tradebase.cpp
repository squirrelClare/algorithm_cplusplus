#include "tradebase.h"
const QString STR_CTS_SERVER_URL = "http://www.easytoo.net:8180/CTSAppSrv/cts";

QString MD5(QString content)
{
    QString md5;
    QByteArray ba,bb;
    QCryptographicHash md(QCryptographicHash::Md5);
    ba.append(content);
    md.addData(ba);
    bb = md.result();
    md5.append(bb.toHex());
    md5 = md5.toUpper();
    return md5;
}


//TODO
TradeBase::TradeBase(MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger)
{
    credit = false;
    creditflag = 0;

    json=new Json();

    CreateXMLBase();
    InitHeader();

    this->debug = debugger;
    this->config = config;
    this->machineInfo = machineInfo;

}


TradeBase::~TradeBase()
{
}

QString TradeBase::GetReqString()
{
    SetResultCode();
    return json->toString();
}

void TradeBase::SetTradeTerminalNo(QString termno)
{
    strTradeTerminalNo = termno;
}

void TradeBase::SetHeadUserID(QString value)
{
    json->SetValue("CTSReqHeader.Userid",value);
}

void TradeBase::SetHeadTxAccount(QString value)
{
    json->SetValue("CTSReqHeader.TxAccount",value);
}

void TradeBase::SetHeadTxAmt(QString value)
{
    json->SetValue("CTSReqHeader.TxAmt",value);
}

void TradeBase::SetHeadContacter(QString value)
{
    json->SetValue("CTSReqHeader.Contacter",value);
}

void TradeBase::SetHeadMsgRefID(QString value)
{
    json->SetValue("CTSReqHeader.MesgRefID",value);
}

void TradeBase::SetHeadOrigSender(QString value)
{
    json->SetValue("CTSReqHeader.OrigSender",value);
}


QString TradeBase::URLencode(QString str)
{
    int i;
    QString result="";
    for(i=0;i<str.length();i++)
    {
        result += "%" + QString::number((int)str[i].toAscii(),16);
    }
    return result;
}

QDomElement TradeBase::getParamsNode()
{
    QDomElement paramsNode;
    QDomElement node;
    int i;

    node = xmlDoc.firstChildElement();
    for(i=0;i<node.childNodes().count();i++)
    {
        if(node.childNodes().item(i).nodeName()=="params")
        {
            paramsNode = node.childNodes().item(i).toElement();
            break;
        }
    }
    return paramsNode;
}



bool TradeBase::PreCharge(Json* json)
{
}

bool TradeBase::PostCharge(Json* json)
{
}

QString TradeBase::GetChargeMoney(Json *json)
{
}

QString TradeBase::ExecuteCharge(Json *json)
{
}

QString TradeBase::GetChargeTxCode(Json *json)
{
    return strTxCode;
}

QStringList TradeBase::GetPrintInfos()
{
}

QString TradeBase::GetSuccessMsg()
{
    return strSuccessMsg;
}

QString TradeBase::GetErrorMsg()
{
    return strErrorMsg;
}


QString TradeBase::EncryptCardNo(QString card)
{
    QString result="";
    if(card.length()>5)
    {
        result = card.left(card.length()-5) + "*****";
    }
    return result;
}

void TradeBase::DoTest()
{

}

void TradeBase::InitHeader()
{
    json->SetValue("CTSReqHeader.Channel","01");
    json->SetValue("CTSReqHeader.TranCode","005019");
    json->SetValue("CTSReqHeader.MesgRefID",QDateTime::currentDateTime().toString("yyyymmddhhmmss"));
    json->SetValue("CTSReqHeader.OrigSender","1000009,21218CCA77804D2BA1922C33E0151105");
    json->SetValue("CTSReqHeader.Userid","");
    json->SetValue("CTSReqHeader.ResultCode","");
    json->SetValue("CTSReqHeader.Comment","");
    json->SetValue("CTSReqHeader.TxAccount","");
    json->SetValue("CTSReqHeader.TxAmt","");
    json->SetValue("CTSReqHeader.Contacter","");
    json->SetValue("CTSReqHeader.TxPage","1");
    json->SetValue("CTSReqHeader.TxRecordNum","20");
    strTradeTerminalNo="35170001";
    strTradePassword="888888";
}

void TradeBase::CreateXMLBase()
{
    QDomProcessingInstruction ins;
    QDomNode rootNode,node;

    ins = xmlDoc.createProcessingInstruction("xml","version=\"1.0\" encoding=\"UTF-8\"");
    xmlDoc.appendChild(ins);
    rootNode = xmlDoc.createElement("root");
    node = xmlDoc.createElement("params");
    rootNode.appendChild(node);
    xmlDoc.appendChild(rootNode);
}


void TradeBase::ClearBodys()
{
    json->Delete("CTSReqBody");
}

void TradeBase::SetResultCode()
{
    QString headstr,bodystr;

    json->SetValue("CTSReqHeader.ResultCode","");

    headstr = json->GetString("CTSReqHeader");
    bodystr = json->GetString("CTSReqBody");

    headstr = headstr.replace(" \"","\""); //去掉空格
    headstr = headstr.replace("\" ","\"");

    bodystr = bodystr.replace("\\\"","\"");
    bodystr = bodystr.replace("\\\\","\\");
    bodystr = bodystr.replace("\\/","/");

    bodystr = bodystr.replace(" \"","\""); //去掉空格
    bodystr = bodystr.replace("\" ","\"");

    json->SetValue("CTSReqHeader.ResultCode",MD5(headstr+bodystr));
}

void TradeBase::AddXMLParam( QString strName, QString strValue)
{
    QDomElement paramsNode= getParamsNode();
    paramsNode.setAttribute(strName,strValue);
}


//TODO
QString TradeBase::RequestInterface(QString json_packet)
{

    Common::WriteDebug("向CTS服务器发送数据：" + json_packet);
    QUrl url = STR_CTS_SERVER_URL;
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/x-www-form-urlencoded");
    request.setHeader(QNetworkRequest::ContentLengthHeader,json_packet.length());

    QNetworkAccessManager *nam = new QNetworkAccessManager();
    QNetworkReply *ret = nam->post(request,json_packet.toAscii());
    QByteArray byteString;
    QString string;
    QEventLoop eventLoop;
    QObject::connect(nam, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
    eventLoop.exec();       //block until finish

    if(ret->error()==QNetworkReply::NoError)
    {
        byteString = ret->readAll();
        QTextCodec *codec=QTextCodec::codecForName("GBK");
        string = codec->toUnicode(byteString);
        Common::WriteDebug("CTS服务器返回数据："+string);
    }
    else
    {
        Common::WriteDebug("CTS服务器返回数据错误！");
        string="";
    }

    ret->deleteLater();;
    return string;
}


void TradeBase::WriteDebugMessage(QString msg)
{
    /*
    if(debug)
    {
        debug->WriteMsg(msg);
    }*/
}

QString TradeBase::GetOrigSender()
{
    return machineInfo->MachineId + ",21218CCA77804D2BA1922C33E0151105";
}

QString TradeBase::GetQueryMesgRefID()
{
    int r;
    QTime time;
    time= QTime::currentTime();
    qsrand(time.msec()+time.second()*1000);
    r=qrand()%9000+1000;

    return time.toString("yyyymmddhhmmss") + QString::number(r);
}

QString TradeBase::GetOrderMesgRefID()
{
    QString BatchNo="";
    QString WatchNo="";

    return BatchNo + "," + WatchNo;
}
void TradeBase::SetTxHeader(QString UserId, QString TxAccount, QString TxAmt, QString Contacter, QString MesgRefID, QString OrigSender)
{


    SetHeadUserID(UserId);
    SetHeadTxAccount(TxAccount);
    SetHeadTxAmt(TxAmt);
    SetHeadContacter(Contacter);
    SetHeadMsgRefID(MesgRefID);
    SetHeadOrigSender(OrigSender);

}

QString TradeBase::GetReturnXML()
{
    return xmlDoc.toString();
}

void TradeBase::ReInitXMLDoc()
{
    xmlDoc.clear();
    CreateXMLBase();
}


QDomElement TradeBase::AddXMLList()
{
    QDomElement paramsNode;
    QDomElement node;
    paramsNode = getParamsNode();
    if(!paramsNode.isNull())
    {
        node = xmlDoc.createElement("list");
        paramsNode.appendChild(node);
    }
    return node;
}

void TradeBase::AddXMLListAttribute(QDomElement node, QString nodeName,QString value)
{
    node.setAttribute(nodeName,value);
}

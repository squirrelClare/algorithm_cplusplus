#include "debugger.h"

Debugger::Debugger(QString filename)
{
    file.setFileName(filename);
    if(file.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        out = new QTextStream(&file);
    }
    else
    {
        out = NULL;
    }
}

Debugger::~Debugger()
{
    if(out != NULL)
    {
    out->flush();
    file.close();
    }
}

void Debugger::WriteMsg(QString msg)
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    if(out != NULL)
    {
        (*out)<< str + ">>" + msg + "\n";
        out->flush();
    }
}

#include "database.h"

Database::Database()
{
    db=QSqlDatabase::addDatabase("QMYSQL");
    isvalid=false;
}

Database::~Database()
{
    if(db.isOpen())
    {
        db.close();
    }
}

bool Database::InitDatabase()
{
    QString dbserver,dbname,dbuser,dbpassword;
    QSettings *setting=new QSettings("Private.ini",QSettings::IniFormat);

    dbpassword = setting->value("Link/password","123456").toString();
    dbuser = setting->value("Link/username","root").toString();
    dbserver = setting->value("Link/server","127.0.0.1").toString();
    dbname = setting->value("Link/database","easytoo").toString();

    db.setHostName(dbserver);
    db.setDatabaseName(dbname);
    db.setUserName(dbuser);
    db.setPassword(dbpassword);
    db.setPort(3306);

    qDebug()<<"database:";
    qDebug()<<"server:" + dbserver;
    qDebug()<<"dbname:" + dbname;
    qDebug()<<"dbuser:" + dbuser;
    qDebug()<<"dbpassword:"+dbpassword;
    isvalid=db.open();
    return isvalid;

}

bool Database::InitDatabase2()
{
    QString dbserver,dbname,dbuser,dbpassword;
    QSettings *setting=new QSettings("Private.ini",QSettings::IniFormat);

    dbpassword = setting->value("Link/password","123456").toString();
    dbuser = setting->value("Link/username","root").toString();
    dbserver = setting->value("Link/server","127.0.0.1").toString();

    db.setHostName(dbserver);
    db.setDatabaseName(dbname);
    db.setUserName(dbuser);
    db.setPassword(dbpassword);
    db.setPort(3306);
    isvalid=db.open();
    return isvalid;

}

bool Database::ExecuteSQL(QString sqlstr)
{
    if(isvalid==false)return false;
    QSqlQuery query;
    sqlstr +=";select 1";
    query=db.exec(sqlstr);
    if(query.numRowsAffected()>0)
    {
        return true;
    }
    else
    {
        return false;
    }


}

bool Database::ExecuteSQL2(QString sqlstr)
{
    if(isvalid==false)return false;
    QSqlQuery query;
    query=db.exec(sqlstr);
    if(query.numRowsAffected()>0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool Database::QuerySQL(QString sqlstr, QSqlQuery *result)
{
    if(isvalid==false)return false;
    qDebug() <<"SQL查询:" + sqlstr;
    *result=db.exec(sqlstr);
    if(result->numRowsAffected()>0)
    {
        return true;
    }
    else
    {
        return false;
    }
}


QString Database::GetString(QString sqlstr)
{
    if(isvalid==false)return "";
    QString result="";
    QSqlQuery query;
    query=db.exec(sqlstr);
    if(query.numRowsAffected()>0)
    {
        if(query.next() && query.isValid())
        {
            result=query.value(0).toString();
        }
    }
    return result;
}

int Database::GetInteger(QString sqlstr)
{
    if(isvalid==false)return -1;
    int result=-1;
    QSqlQuery query;
    query=db.exec(sqlstr);
    if(query.numRowsAffected()>0)
    {
        if(query.next() && query.isValid())
        {
            result=query.value(0).toInt();
        }
    }

    return result;
}

bool Database::IsValid()
{
    return isvalid;
}

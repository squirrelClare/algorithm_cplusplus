#include "globalconfig.h"

GlobalConfig::GlobalConfig()
{
#ifdef DEBUG_VERSION
    setting = new QSettings("UnionPay_debug.ini",QSettings::IniFormat);
#else
    setting = new QSettings("UnionPay.ini",QSettings::IniFormat);
#endif

    privateSetting = new QSettings("Private.ini",QSettings::IniFormat);
    posSetting = new QSettings("DevicePos.ini",QSettings::IniFormat);

    TerminalID = privateSetting->value("Info/TerminalID","300046").toString();
    WebSrvAddr = privateSetting->value("Info/WebSrvAddr","0").toString();
    Union_ComPort = setting->value("UnionPay/UnionPayComPort","1").toInt();
    Union_TerminalID = setting->value("UnionPay/TerminalNo","000000").toString();
    Union_TerminalPassWord = setting->value("UnionPay/TerminalPassword","easytoo").toString();

    Union_PaySerialNo = posSetting->value("YL_M/yl_watchno_m","").toString();
    if(Union_PaySerialNo=="")
    {
        Union_PaySerialNo = setting->value("UnionPay/UnionPayserialNo","").toString();
        posSetting->setValue("YL_M/yl_watchno_m",Union_PaySerialNo);
    }

    Union_PayBatchNo = posSetting->value("YL_M/yl_batchno_m","").toString();
    if(Union_PayBatchNo=="")
    {
        Union_PayBatchNo = setting->value("UnionPay/UnionPayBatchNo","").toString();
        posSetting->setValue("YL_M/yl_batchno_m",Union_PayBatchNo);
    }

    ePayLinks_SerialNo = setting->value("epaylink/ePayLinksSerialNo","888888").toString();
    Print_ComPort = setting->value("Print/PrintComPort","2").toInt();
    Union_PaySerialNo = QString::number(Union_PaySerialNo.toInt()+1);

    qDebug()<< "Read ini finished:";
    qDebug()<< "TerminalID:" + TerminalID;
    qDebug()<< "WebSrvAddr:" + WebSrvAddr;
    qDebug()<<"Union_ComPort:" + QString::number(Union_ComPort);
    qDebug()<<"Union_TerminalID:"+Union_TerminalID;
    qDebug()<<"Union_TerminalPassWord:"+Union_TerminalPassWord;
    qDebug()<<"Union_PaySerialNo:"+Union_PaySerialNo;
    qDebug()<<"Union_PayBatchNo:"+Union_PayBatchNo;
    qDebug()<<"ePayLinks_SerialNo:"+ePayLinks_SerialNo;
    qDebug()<<"Print_ComPort:"+QString::number(Print_ComPort);
    qDebug()<<"Union_PaySerialNo:"+Union_PaySerialNo;

}

QString GlobalConfig::Get_AreaID()
{
    return FAreaID;
}

QString GlobalConfig::Get_TerminalID()
{
    return TerminalID;
}


void GlobalConfig::Asc_ePayLinks_SerialNo()
{
    ePayLinks_SerialNo = QString::number( ePayLinks_SerialNo.toInt()+1);
    setting->setValue("epaylinks/ePayLinksSerialNo",ePayLinks_SerialNo);
}

QString GlobalConfig::GetWebSrvAddr()
{
    return WebSrvAddr;
}


void GlobalConfig::Asc_Union_PaySerialNo_100()
{
    Union_PaySerialNo =QString::number(Union_PaySerialNo.toInt()+100);
    if(Union_PaySerialNo.toInt()>999999)
    {
        Union_PaySerialNo="1";
        Union_PayBatchNo =QString::number( Union_PayBatchNo.toInt()+1);
    }
    setting->setValue("UnionPay/UnionPaySerialNo",Union_PaySerialNo);
    setting->setValue("UnionPay/UnionPayBatchNo",Union_PayBatchNo);

}

void GlobalConfig::Save_Union_PaySerialNo(QString PaySerialNo)
{
    setting->setValue("UnionPay/UnionPaySerialNo",Union_PaySerialNo);
}


void GlobalConfig::Asc_Union_PaySerialNo()
{
    Union_PaySerialNo =QString::number(Union_PaySerialNo.toInt()+1);
    if(Union_PaySerialNo.toInt() >999999)
    {
        Union_PaySerialNo="1";
        Union_PayBatchNo =QString::number( Union_PayBatchNo.toInt()+1);
    }
    setting->setValue("UnionPay/UnionPaySerialNo",Union_PaySerialNo);
    setting->setValue("UnionPay/UnionPayBatchNo",Union_PayBatchNo);

}


QString GlobalConfig::Get_Union_TerminalPassword()
{
    return Union_TerminalPassWord;
}

QString GlobalConfig::Get_Union_PaySerialNo()
{
    QSettings *ini = new QSettings("DevicePos.ini",QSettings::IniFormat);
    return ini->value("YL_M/yl_watchno_m","").toString();
}

QString GlobalConfig::Get_Union_PayBatchNo()
{
    QSettings *ini = new QSettings("DevicePos.ini",QSettings::IniFormat);
    return ini->value("YL_M/yl_batchno_m","").toString();
}

QString GlobalConfig::Get_ePayLinks_SerialNo()
{
    return ePayLinks_SerialNo;
}


QString GlobalConfig::Get_Union_TerminalID()
{
    return Union_TerminalID;
}


int GlobalConfig::Get_Union_ComPort()
{
    return Union_ComPort;
}


int GlobalConfig::Get_Print_ComPort()
{
    return Print_ComPort;
}

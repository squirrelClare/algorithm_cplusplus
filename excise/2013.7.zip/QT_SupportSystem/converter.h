#ifndef CONVERTER_H
#define CONVERTER_H
#include <QDomDocument>
#include "json.h"
class Converter
{
public:
    Converter();

    QString JsonToXmlFull(QString jsonStr);
    QString JsonToXmlFullWithCommand(QString jsonStr,QString command,QString oper);
    QString JsonToXmlPart(QString jsonStr);
    QString XmlFullToJson(QString xmlStr);
    QString XmlPartToJson(QString xmlStr);
private:
    void XmlOperOneNode(QDomNode node, Json json,QString prePath);
    void JsonOperOneNode(Json json, QDomNode node);



};

#endif // CONVERTER_H

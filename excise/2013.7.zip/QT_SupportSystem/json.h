#ifndef JSON_H
#define JSON_H
#include <parser.h>
#include <serializer.h>
#include <QVariant>
#include <QVariantList>
#include <QStringList>
class Json
{
public:
    Json();
    Json(QString json);

    QString GetValue(QString key);
    bool AddValue(QString key,QString value);
    bool SetValue(QString key,QString value);
    bool AddJson(QString key,Json json);
    bool AddList(QString key,QStringList list);

    QString GetString(QString key);
    QString GetString(QString key,int index);
    QString GetString(QString key,QVariant json);

    QString GetType(QString key);
    int GetCount(QString key);

    QString GetName(QString key,int index);
    QString GetValue(QString key,int index);
    QString GetJson(QString key,int index);
    bool Delete(QString key);

    bool IsValid();

    QString operator[] (QString key);


    QString toString();
    QVariant toVariant();

private:
    QVariant SetValue(QString key,QString value,QVariant json);
    QVariant AddJson(QString key, QVariant value, QVariant json);
    QVariant AddList(QString key, QStringList value,QVariant json);
    QVariant Delete(QString key,QVariant json);

    QVariant GetVariant(QString key,QVariant json);

    QVariant json_obj;
    QString json_string;

    bool isValid;
};

#endif // JSON_H

#include "messageflex.h"



MessageFlex::MessageFlex()
{
    curDir = QDir::currentPath() + "/debug/";
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    g_debuger = new Debugger(curDir + time.toString("yyyyMMdd") + "log.txt");

    db=new Database();
    db->InitDatabase();
    if(db->IsValid())
    {
        WriteDebug("与数据库连接成功");
    }
    else
    {
        WriteDebug("与数据库连接失败，请检查原因！");
    }

    config = new GlobalConfig();
    machineInfo = new MachineInfo(db);



    unionPay = new UnionPay(this,db,g_debuger);
    uploader = new ConsumeUploader("http://www.easytoo.net:8280/EasytooMonSrv/monitor",g_debuger);

    /********************************************
     *             创建所有业务对象                *
     ********************************************/
    appMobileRecharge = new MobileRecharge(&map,machineInfo,config,g_debuger);
    appGameRecharge = new GameRecharge(&map,machineInfo,config,g_debuger);
    appCompanyList = new ComanyList(&map,db,machineInfo,config,g_debuger);
    appOnlineMall = new OnlineMall(&map,machineInfo,config,g_debuger);
    appPictureDownloader = new PictureDownloader(&map,machineInfo,config,g_debuger);
    appWeather = new Weather(&map,machineInfo,config,g_debuger);
    appPlaneTicket = new PlaneTicket(&map,machineInfo,config,g_debuger);
    appCoupon = new Coupon(&map,db,machineInfo,config,g_debuger);
    appTrafficTax = new TrafficTax(&map,machineInfo,config,g_debuger);
    appCreditRecharge = new CreditRecharge(&map,machineInfo,config,g_debuger);
    appMovieTicket = new MovieTicket(&map,machineInfo,config,g_debuger);
    appMovieCommonTicket = new MovieCommonTicket(&map,machineInfo,config,g_debuger);

    WriteDebug("------------已有功能列表--------------");

    for(int i=0;i<map.count();i++)
    {
        WriteDebug(" 命令 " + map.keys().at(i) + " : " + map[map.keys().at(i)].desc) ;
    }
    WriteDebug("------------------------------------");

    server = new QTcpServer();
    server->setMaxPendingConnections(256);
    if(server->listen(QHostAddress::LocalHost,8001))
    {
        //监听成功
        QObject::connect(server,SIGNAL(newConnection()),this,SLOT(On_Server_NewConnIn()));
        WriteDebug("已启动与FLEX通讯监听，端口为：" + QString::number(8001));
    }
    else
    {
        //监听失败
        WriteDebug("启动FLEX通讯监听失败！");
    }

    secureServer = new QTcpServer();
    secureServer->setMaxPendingConnections(256);
    if(secureServer->listen(QHostAddress::LocalHost,847))
    {
        //监听成功
        QObject::connect(secureServer,SIGNAL(newConnection()),this,SLOT(On_SecureServer_NewConnIn()));
        WriteDebug("已启动服务端口监听，端口为" + QString::number(847));
    }
    else
    {
        WriteDebug("安全服务器监听失败");
    }

    client = new QTcpSocket();
    QObject::connect(client,SIGNAL(readyRead()),this,SLOT(On_Client_DataIn()));

    secureClient = new QTcpSocket();
    QObject::connect(secureClient,SIGNAL(readyRead()),this,SLOT(On_SecureServer_NewConnIn()));



}

MessageFlex::~MessageFlex()
{
    /*
    client->close();
    secureClient->close();
    server->close();
    secureServer->close();
    */
}

//OK
void MessageFlex::AddRandomToUnipaySer()
{
    QSettings *setting;
    QString fileName;
    QString iniFileName;

    fileName = QDir::currentPath() + "/uniserchanged.dat";
    QFile file(fileName);

    iniFileName = QDir::currentPath() + "/UnionPay.ini";
    int ti;
    if(file.exists()==false)
    {
        setting = new QSettings(iniFileName,QSettings::IniFormat);
        ti = setting->value("UnionPay/UnionPaySerialNo","0").toInt();
        qsrand(QTime::currentTime().msec());
        ti += qrand();
        setting->setValue("UnionPay/UnionPaySerialNo",QString::number(ti));

        file.open(QIODevice::WriteOnly | QIODevice::Append);
        file.close();

    }

}

void MessageFlex::BeforeUnionPayConsume()
{

}

void MessageFlex::DoAfterSignIn(bool isSuccess)
{
    if(isSuccess==false)
    {

    }
}

void MessageFlex::DoAfterService(bool isSuccess, TradeBase *tradebase)
{
    QString msg;
    if(isSuccess)
    {
        msg= tradebase->GetSuccessMsg();
    }
    else
    {
        msg = "交易失败,系统即将执行银联退款...";
    }

    GotoPage(P_CommonInfo,msg);
    if(isSuccess)
    {
        Common::Sleep(3000);
    }
    else
    {
        Common::Sleep(2000);
    }
}

QString MessageFlex::CommonCharge(Json *json, TradeBase *tradebase)
{
    QString returnstr;
    int slotCardReturn;

    bool isCredit;
    QString creditCardNo;

    QString money;
    QString operate;
    int consumeResult;

    curTradeBase = tradebase;
    operate = json->GetString("header.operate");

    curModule = json->GetString("header.module");

    money = tradebase->GetChargeMoney(json);

    if (json->GetType("header.creditcardno")=="JSON_END_NODE")
    {
        isCredit = true;
        creditCardNo = json->GetString("header.creditcardno");
    }
    else
    {
        isCredit = false;
        creditCardNo="";
    }

    if(tradebase->PreCharge(json))
    {
        BeforeUnionPayConsume();

        consumeResult=unionPay->Consume(money.toInt());

        if(UploadInfo(json,consumeResult,tradebase,"1","2","2,","2","3")==false)
        {
            //失败,进行冲正
            if(consumeResult==0)
            {
                //DoBeforeUnionBak;
                //DoAfterUnionBak(Union.UnionPay_Backout, Union.WatchNo, Union.BatchNo, Union.ConsumeFee, Union.ComsumeTime, Union.CardNo);
            }

        }
        else
        {
            //成功
            //SetTxHeader(config->Get_Union_TerminalID(),"11","","",GetOrderMesgRefID("1","2"),GetOrigSender(),tradebase);
            tradebase->SetTradeTerminalNo(machineInfo->MachineId);

            returnstr = tradebase->ExecuteCharge(json);
            Common::Sleep(5000);

            DoAfterService(tradebase->srvsuccess,tradebase);

            if(tradebase->srvsuccess==false)
            {
                //冲正交易
                //DoBeforeUnionBak;
                //DoAfterUnionBak(Union.UnionPay_Backout, Union.WatchNo, Union.BatchNo, Union.ConsumeFee, Union.ComsumeTime, Union.CardNo);
            }
        }
    }
    else
    {
        GotoPage(P_CommonInfo,tradebase->GetErrorMsg());
        Common::Sleep(2000);
    }
    Common::Sleep(2000);
    GotoPage(P_MAIN,"");
    curTradeBase=NULL;

    return returnstr;
}

bool MessageFlex::UploadInfo(Json *json, int operResult, TradeBase *tradebase, QString watchNo,QString batchNo, QString consumeFee, QString consumeTime, QString cardNo)
{
    QString upflag;
    QString msg;
    bool uploadResult;

    bool isToContinue;

    if(operResult==0)
    {
        //操作成功
        upflag="1";
    }
    else
    {
        upflag = "cts" + QString::number(operResult);
    }

    //将扣款信息上传到服务器
    uploadResult=uploader->UploadConsumeInfo(machineInfo->MachineId,1,upflag,config->PaySerialNo
                                ,config->PayBatchNo,config->CardNo,consumeTime,consumeFee,tradebase->GetChargeTxCode(json));

    if(operResult==0 && uploadResult==true)
    {
        msg="银联扣款成功，准备提供服务...";
        isToContinue=true;
    }
    else if(operResult==0 && uploadResult==false)
    {
        msg="银联扣款成功，但在后续操作遇到网络故障，交易即将终止，请稍候重试...";
        isToContinue=false;
    }
    else
    {
        msg="银联扣款失败,本次交易即将终止...";
        isToContinue=false;
    }

    GotoPage(P_CommonInfo,msg);
    Common::Sleep(2000);

    return isToContinue;

}

void MessageFlex::GotoPage(ENUM_Page page, QString msg)
{
    QString result = GetPageString(page,msg);
    SendXMLToFlex(result);
}

void MessageFlex::HandleClient(QString command)
{
    int cmd,oper;
    QString SecondStr;

    QString temp;
    g_IsBusy = true;

    cmd=10000;
    oper=10000;
    if(command == "<policy-file-request/>")
    {
        SecondStr = "<?xml version=\"1.0\"?><cross-domain-policy><site-control permitted-cross-domain-policies=\"all\"/>";
        SecondStr += "<allow-access-from domain=\"*\" to-ports=\"*\"></cross-domain-policy>\n";
        SendXMLToFlex(SecondStr);
        g_IsBusy=false;
        return;
    }


    Converter *converter = new Converter();

    QString jsonStr = converter->XmlFullToJson(command);


    Json *vJson = new Json(jsonStr);
    QString key=vJson->GetString("header.command")+","+vJson->GetString("header.operate");
    cmd = vJson->GetString("header.command").toInt();
    oper = vJson->GetString("header.operate").toInt();
    temp = vJson->toString();
    WriteDebug(vJson->toString());

    if(map.keys().contains(key))
    {
        WriteDebug("开始处理命令：" + map[key].desc + "\n" + command);
        //调用对应的处理函数，并将结果发送给FLEX
        SendXMLToFlex((map[key].app->*map[key].func)(vJson));
    }
    else
    {
        WriteDebug("指令" + key + "找不到处理函数！");
    }


    g_IsBusy = false;
}

bool MessageFlex::SendXMLToFlex(QString xml)
{
    char buf[3]={0,0,0};

    WriteDebug("向FLEX发送数据：\r\n" + xml);
    if(client->isOpen() && client->isValid())
    {
        client->write(xml.toLocal8Bit());
        client->write(buf,1);
        return true;
    }
    else
    {
        WriteDebug("向FLEX发向数据失败，未与FLEX建立连接");
        return false;
    }

}


void MessageFlex::WriteDebug(QString string)
{
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    qDebug()<< str + "---" + string;
    emit OnNewLogInfo(str + "---" + string);
}

void MessageFlex::On_Server_NewConnIn()
{
    client = server->nextPendingConnection();
    if(client->isValid())
    {
        WriteDebug("已建立与FLEX的连接！");
        QObject::connect(client,SIGNAL(readyRead()),this,SLOT(On_Client_DataIn()));
    }
}

void MessageFlex::On_SecureServer_NewConnIn()
{

}

void MessageFlex::On_Client_DataIn()
{
    QByteArray byteData;
    QString command;

    WriteDebug("准备接收FLEX数据");
    if(client->isOpen() && client->isValid())
    {
        byteData=client->readAll();
        if(byteData.length()>0)
        {
            WriteDebug("接收到FLEX数据，数据长度为：" + QString::number(byteData.length()));
            command = byteData;            
            if(command != "")
            {
                HandleClient(command);
            }
        }
    }


}

void MessageFlex::On_SecureClient_DataIn()
{
    QByteArray byteData;
    QString cmd;
    QString retcmd;
    if(secureClient->isOpen() && secureClient->isValid())
    {
        byteData=secureClient->readAll();
        if(byteData.length()>0)
        {
            cmd = byteData;

            if(cmd=="<policy-file-request/>")
            {
                retcmd = "<?xml version=\"1.0\"?><cross-domain-policy><site-control permitted-cross-domain-policies=\"all\"/><allow-access-from domain=\"*\" to-ports=\"*\"></cross-domain-policy>\n";
                secureClient->write(retcmd.toAscii());
            }
        }
    }
}


QString MessageFlex::GetPageString(ENUM_Page page, QString msg)
{
    QDomProcessingInstruction ins;
    QDomElement rootNode,node;
    QDomDocument xmlDoc;
    ins = xmlDoc.createProcessingInstruction("xml","version=\"1.0\" encoding=\"UTF-8\"");
    xmlDoc.appendChild(ins);
    rootNode = xmlDoc.createElement("root");
    node = xmlDoc.createElement("params");



    QString result="";
    switch(page)
    {
    case P_WaitCard:
        //result =  "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><params command=\"1000\" operate=\"1001\" module=\""+curModule+"\" message=\"" + msg + "\"></params></root>";
        node.setAttribute("command","1000");
        node.setAttribute("operate","1001");
        node.setAttribute("module",curModule);
        node.setAttribute("message",msg);
        break;
    case P_DisPassWord:
        //result="<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><params command=\"1000\" operate=\"1002\"></params></root>";
        node.setAttribute("command","1000");
        node.setAttribute("operate","1002");
        break;
    case P_CommonInfo:
        //result="<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><params command=\"1000\" operate=\"1003\" message=\"" + msg + "\"></params></root>";
        node.setAttribute("command","1000");
        node.setAttribute("operate","1003");
        node.setAttribute("message",msg);
        break;
    case P_MAIN:
        //result="<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><params command=\"1000\" operate=\"1004\" money=\""+curTradeBase->flag+"\"></params></root>";
        node.setAttribute("command","1000");
        node.setAttribute("operate","1004");
        node.setAttribute("money",curTradeBase->flag);
        break;
    case P_PubError:
        //result = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><params command=\"1000\" operate=\"1005\" message=\"" + msg + "\"></params></root>";
        node.setAttribute("command","1000");
        node.setAttribute("operate","1005");
        node.setAttribute("message",msg);
        break;
    case P_Weather:
        result=msg;
        break;
    default:
        result="";
        break;

    }
    rootNode.appendChild(node);
    xmlDoc.appendChild(rootNode);
    return xmlDoc.toString();
}

#ifndef COMMON_H
#define COMMON_H
#include <QString>
#include <QTextStream>
#include <QFile>
#include <QDebug>
#include <QTime>
#include <QWaitCondition>
#include <QMutex>
#include <QDir>
#include <QtNetwork>
class Common
{
public:
    Common();
    static bool LoadFromFile(QString filename,QString *out);
    static QString LoadFromFile(QString filename);
    static bool SaveToFile(QString filename,QString content);
    static void WriteDebug(QString string);
    static void Sleep(unsigned int time);
    static bool MkDir(QString path);
    static QString RequestServer(QString serverAddress,QString data);

};

#endif // COMMON_H

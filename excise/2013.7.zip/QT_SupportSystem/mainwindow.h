#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <parser.h>
#include <serializer.h>
#include <QDebug>
#include "json.h"
#include "tradebase.h"
#include "messageflex.h"
#include "converter.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private:
    Ui::MainWindow *ui;
    MessageFlex *flex;
public slots:
    void AddMemo(QString msg);

};

#endif // MAINWINDOW_H

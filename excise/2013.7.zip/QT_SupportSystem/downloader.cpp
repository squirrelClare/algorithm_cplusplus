#include "downloader.h"

Downloader::Downloader(QStringList list,QObject *parent) :
    QThread(parent)
{
    QStringList item;
    for(int i=0;i<list.count();i++)
    {
        item = list.at(i).split("@");
        QFile *file=new QFile(item.at(0));
        if(file->exists()==false)
        {
        fileList.append(item.at(0));
        urlList.append(item.at(1));
        }
    }


}

void Downloader::run()
{
    QNetworkReply* reply;
    nam = new QNetworkAccessManager(0);
    int count=0;
    while(count<urlList.count())
    {

        reply = nam->get(QNetworkRequest(QUrl(urlList.at(count))));

        QEventLoop eventLoop;
        QObject::connect(nam, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
        eventLoop.exec();       //block until finish

        QByteArray data = reply->readAll();

        QFile *file = new QFile(fileList.at(count));
        QFileInfo *fileInfo = new QFileInfo(*file);
        Common::MkDir(fileInfo->dir().absolutePath());
        if(file->open(QIODevice::WriteOnly))
        {
            file->write(data);
            file->flush();
            file->close();
            qDebug() << QString::fromLocal8Bit( "成功下载") + urlList.at(count) + QString::fromLocal8Bit("到本地") + fileList.at(count);
        }
        else
        {
            qDebug() << "无法打开本地文件:" + fileList.at(count);

        }

        count++;
    }

    qDebug()<<"所有文件下载完成！";
    emit downloadFinished();
}

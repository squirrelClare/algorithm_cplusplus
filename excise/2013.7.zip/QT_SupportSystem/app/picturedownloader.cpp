﻿#include "picturedownloader.h"

PictureDownloader::PictureDownloader(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("5011,1001",
    {
                    this,
                    (CmdProcFun)&PictureDownloader::DownPicture,
                    "下载图片"
                });
    map->insert("5008,1001",
    {
                    this,
                    (CmdProcFun)&PictureDownloader::GetRunTimeInfo,
                    "查询运行信息"
                });

}

QString PictureDownloader::DownPicture(Json *json)
{
    QString result="<?xml version=\"1.0\"?><root><params command=\"5011\" operate=\"1001\" imgpage=\"" + json->GetString("header.imgpage") + "\"  success=\"1\" errormsg=\"\"></params></root>";
    Downloader *downloader;
    QStringList list;
    Json* item;
    QFile file;

    int count=json->GetCount("body.lists");
    for(int i=0;i<count;i++)
    {
        item = new Json(json->GetJson("body.lists",i));
        file.setFileName(item->GetString("localurl"));

        if(file.exists()==false)
        {
            list.append("D:/iberry/bin/" +item->GetString("localurl") + "@" + item->GetString("remoteurl"));
        }
    delete item;
    }
    if(list.count() > 0)
    {
        downloader = new Downloader(list);
        downloader->start();

        QEventLoop eventLoop;
        QObject::connect(downloader,SIGNAL(downloadFinished()),&eventLoop,SLOT(quit()));
               eventLoop.exec();       //block until finish
               delete downloader;

    }

    return result;
}
QString PictureDownloader::GetRunTimeInfo(Json *json)
{
    QStringList ps;
    QString pstext;
    Json *vJson;
    QString xmlstr;
    QString tmp;
    QString result;

    pstext = GetFlexFunInfoFromServer();
    if(pstext!="")
    {
        vJson = new Json(pstext);
        tmp = vJson->GetString("MapRespBody");
        xmlstr = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><params command=\"5008\" operate=\"1001\" agentInfo=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.agentInfo") + "\"" + " agentid=\"" + vJson->GetString("MapRespBody.MapRespBody3.agentid") + "\"" +
            " agentsts=\"" + vJson->GetString("MapRespBody.MapRespBody3.agentsts") + "\"" + " chktime=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.chktime") + "\"" + " contacter=\"" + vJson->GetString("MapRespBody.MapRespBody3.contacter") + "\"" +
            " crtdate=\"" + vJson->GetString("MapRespBody.MapRespBody3.crtdate") + "\"" + " crtuser=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.crtuser") + "\"" + " ctspwd=\"" + vJson->GetString("MapRespBody.MapRespBody3.ctspwd") + "\"" +
            " hostconfig=\"" + vJson->GetString("MapRespBody.MapRespBody3.hostconfig") + "\"" + " installtime=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.installtime") + "\"" + " installusrs=\"" + vJson->GetString("MapRespBody.MapRespBody3.installusrs") +
            "\"" + " location=\"" + vJson->GetString("MapRespBody.MapRespBody3.location") + "\"" + " locationbus=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.locationbus") + "\"" + " locationcity=\"" + vJson->GetString("MapRespBody.MapRespBody3.locationcity")
            + "\"" + " locationprov=\"" + vJson->GetString("MapRespBody.MapRespBody3.locationprov") + "\"" + " openflag=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.openflag") + "\"" + " opentimes=\"" + vJson->GetString("MapRespBody.MapRespBody3.opentimes") + "\"" +
            " payterm=\"" + vJson->GetString("MapRespBody.MapRespBody3.payterm") + "\"" + " termgroupid=\"" +
            vJson->GetString("MapRespBody.MapRespBody3.termgroupid") + "\"" + " termno=\"" + vJson->GetString("MapRespBody.MapRespBody3.termno") + "\"" +
            " termstatus=\"" + vJson->GetString("MapRespBody.MapRespBody3.termstatus") + "\" ></params></root>";
        result = xmlstr;
        delete vJson;
    }
    else
    {
        result="";
    }
    return result;
}

QString PictureDownloader::GetFlexFunInfoFromServer()
{

    Json * vJson1,*vJson2;
    QString fname;
    QString result;


    fname = QDir::currentPath() + "termparm.txt";
    if(Common::LoadFromFile(fname,&result)==true)
    {

        return result;
    }
    else
    {

        vJson1 = new Json();
        vJson1->SetValue("MapReqHeader.EventType","01");
        vJson1->SetValue("MapReqHeader.Param","0");
        vJson1->SetValue("MapReqBody.MapReqBody1.Termno","10000001");

        result=Common::RequestServer("http://www.easytoo.net:8280/EasytooMonSrv/mapmon",vJson1->toString());
        if(result!="")
        {
            vJson2=new Json(result);
            if(vJson2->GetString("MapRespHeader.Status")=="0")
            {
                Common::SaveToFile(fname,result);
            }
            delete vJson2;
        }
    delete vJson1;
        return result;
    }
}

#ifndef WEATHER_H
#define WEATHER_H
#include <QString>

#include "tradebase.h"
#include "debugger.h"
#include <QString>
#include <QtXml>
class Weather : public TradeBase
{
public:
    Weather(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;
    QString QueryWeather(QString areaCode,QString term);
    QString DownWeatherData(QString areaID);
    QString SendWeather(Json *json);
private:
    QString ParseWeatherInfo(QString returnStr);
    bool downloaded;
};

#endif // WEATHER_H

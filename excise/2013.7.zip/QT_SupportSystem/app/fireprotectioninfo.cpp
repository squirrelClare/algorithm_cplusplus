#include "fireprotectioninfo.h"

FireProtectionInfo::FireProtectionInfo(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    this->machineInfo = machineInfo;
    this->db = db;
}

QString FireProtectionInfo::QueryButton(Json *json)
{
    QString sql;
    QString pid;
    QSqlQuery query;
    QSqlRecord rs;
    QDomElement vNode;
    int page,pageCount;
    int buttonCount;
    int articleCount;

    ReInitXMLDoc();
    AddXMLParam("command","5009");
    AddXMLParam("operate","1001");

    page = json->GetString("header.page").toInt();
    pageCount = json->GetString("header.pagecount").toInt();
    pid = json->GetString("header.pid");
    if(pid=="0")
    {
        pid = typeID;
    }

    if(page==-1)
    {
        sql = "SELECT count(id) as buttoncount FROM et_category WHERE parent_id="+pid;
        buttonCount = db->GetInteger(sql);
        AddXMLParam("buttoncount",QString::number(buttonCount));
        sql="SELECT id,title FROM et_category  WHERE parent_id=" + pid + " limit 0," + QString::number(pageCount>buttonCount ? buttonCount : pageCount);
    }
    else
    {
        sql="SELECT id,title FROM et_category  WHERE parent_id=" + pid + " limit " + QString::number((page - 1)*pageCount) +"," + QString::number(pageCount);
    }

    if(db->QuerySQL(sql,&query))
    {
        AddXMLParam("success","1");
        while(query.next())
        {
            rs = query.record();
            vNode = AddXMLList();
            AddXMLListAttribute(vNode,"id",rs.field("id").value().toString());
            AddXMLListAttribute(vNode,"title",rs.field("title").value().toString());
            articleCount = db->GetInteger("select count(*) as articalcount from et_article where category_id=" + rs.field("id").value().toString());
            AddXMLListAttribute(vNode,"articalcount",QString::number(articleCount));

        }
    }

    return GetReturnXML();

}

QString FireProtectionInfo::QueryArticleList(Json *json)
{

    QString sql;
    QString pid;
    QSqlQuery query;
    QSqlRecord rs;
    QDomElement vNode;
    int page,pageCount;
    int buttonCount;
    int articleCount;

    ReInitXMLDoc();
    AddXMLParam("command","5009");
    AddXMLParam("operate","1003");

    page = json->GetString("header.page").toInt();
    pageCount = json->GetString("header.pagecount").toInt();
    pid = json->GetString("header.pid");
    if(pid=="0")
    {
        pid = typeID;
    }

    if(page==-1)
    {
        sql = "SELECT count(*) as buttoncount FROM et_article WHERE category_id ="+pid;
        buttonCount = db->GetInteger(sql);
        AddXMLParam("buttoncount",QString::number(buttonCount));
        sql="SELECT id,title,from_unixtime(put_time) as put_time FROM et_article WHERE category_id" + pid + " limit 0," + QString::number(pageCount>buttonCount ? buttonCount : pageCount);
    }
    else
    {
        sql="SELECT id,title,from_unixtime(put_time) as put_time FROM et_article WHERE category_id" + pid + " limit " + QString::number((page - 1)*pageCount) +"," + QString::number(pageCount);
    }

    if(db->QuerySQL(sql,&query))
    {
        AddXMLParam("success","1");
        while(query.next())
        {
            rs = query.record();
            vNode = AddXMLList();
            AddXMLListAttribute(vNode,"id",rs.field("id").value().toString());
            AddXMLListAttribute(vNode,"title",rs.field("title").value().toString());
            AddXMLListAttribute(vNode,"put_time",rs.field("put_time").value().toString());

        }
    }

    return GetReturnXML();

}

#ifndef TRAFFICTAX_H
#define TRAFFICTAX_H
#include<QString>
#include <QtXml>
#include<debugger.h>
#include<tradebase.h>
#include<json.h>
class TrafficTax:public TradeBase
{private:
    QString ParseDirectCharge(QString returnStr);
    void InitPrintInfo();
    void SetBasePrintInfo(QString busstype,QString trancode,QString tranmoney,QString trantime);
   void SetPrintInfoSystemCode(QString systemcode);
public:
    TrafficTax(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;
    ~TrafficTax();
    QString DirectCharge(Json  *json);
        QString ExecuteCharge(Json  *json);
        QString GetChargeMoney(Json *json);
        QString GetChargeTxCode(Json *json);
};

#endif // TRAFFICTAX_H

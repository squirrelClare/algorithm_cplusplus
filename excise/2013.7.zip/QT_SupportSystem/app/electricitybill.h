#ifndef ELECTRICITYBILL_H
#define ELECTRICITYBILL_H
#include "debugger.h"
#include "tradebase.h"
#include "database.h"
#include "json.h"
#include <QString>
class ElectricityBill : public TradeBase
{
public:
    ElectricityBill(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);
    QString TestCharge();

private:
    QString ChargeConfirm(Json *json1,Json* json2);
    QString ChargeRequest(Json *json);
    QString Charge(Json *json);
    QString ParseCharge(QString returnStr);
    QString ParseChargeConfirm(QString returnStr);
    QString ParseChargeRequest(QString returnStr);

};

#endif // ELECTRICITYBILL_H

#ifndef FIREPROTECTIONINFO_H
#define FIREPROTECTIONINFO_H
#include "tradebase.h"
#include "machineinfo.h"
#include "debugger.h"
#include "database.h"
#include "json.h"

#include<QString>
#include<QSqlRecord>
#include<QSqlField>
#include <QSqlDatabase>
#include <QtXml>

class FireProtectionInfo : public TradeBase
{
public:
    FireProtectionInfo(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;
    QString QueryButton(Json *json);
    QString QueryArticleList(Json* json);
    QString QueryArticle(Json* json);

private:
    MachineInfo *machineInfo;
    Database *db;
    QString typeID;
};

#endif // FIREPROTECTIONINFO_H

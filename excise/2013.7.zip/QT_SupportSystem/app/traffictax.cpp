﻿#include "traffictax.h"

TrafficTax::TrafficTax(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("11,12",
    {
                    this,
                    (CmdProcFun)&TrafficTax::ExecuteCharge,
                    "车船税"
                });
    InitPrintInfo();
}

TrafficTax::~TrafficTax()
{

}


QString TrafficTax::ParseDirectCharge(QString returnStr)
{
    Json* vJson;
    srvsuccess=true;


    ReInitXMLDoc();
    AddXMLParam("command", "11");
    AddXMLParam("operate", "12");
    if (returnStr=="")
    {
        AddXMLParam("success", "1");
        SetPrintInfoSystemCode("00000000");
        return GetReturnXML();
    }
    vJson=new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode("00000001");
        return GetReturnXML();
    }
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success", "0");
        AddXMLParam("errormsg", vJson->GetString("CTSRespHeader.Comment"));
           srvsuccess = false;
    }
    else
    {
        AddXMLParam("success", "1");
        SetPrintInfoSystemCode(vJson->GetString("CTSRespHeader.MesgRefID"));
    }
  delete vJson;
    return  GetReturnXML();
}

void TrafficTax::InitPrintInfo()
{
}


void TrafficTax::SetPrintInfoSystemCode(QString systemcode)
{
}


void TrafficTax::SetBasePrintInfo(QString busstype, QString trancode, QString tranmoney, QString trantime)
{

}


QString TrafficTax::DirectCharge(Json *json)
{

    QString amount;

    ClearBodys();
    amount=QString::number(json->GetString("header.amuont").toInt()*100);
    this->json->SetValue("CTSReqHeader.TranCode","021001");
    this->json->SetValue("CTSReqBody.mobile",json->GetString("header.mobile"));
    this->json->SetValue("CTSReqBody.license",json->GetString("header.license"));
    this->json->SetValue("CTSReqBody.volume",json->GetString("header.volume"));
    this->json->SetValue("CTSReqBody.amount",amount);
    this->json->SetValue("CTSReqBody.Head.Transaction","0");
    this->json->SetValue("CTSReqBody.Head.Ver","1");

    strSuccessMsg = "您的订单已提交，请稍后留意短信通知！";
    InitPrintInfo();
    //SetBasePrintInfo('车船税', '021001',json->GetString("header.amount",FormatDateTime("yyyy-mm-dd hh:mm:ss"), Now));
    return ParseDirectCharge(RequestInterface(GetReqString()));

}

QString TrafficTax::ExecuteCharge(Json *json)
{
    return DirectCharge(json);
}

QString TrafficTax::GetChargeMoney(Json *json)
{
    return json->GetString("header.amount");
}

QString TrafficTax::GetChargeTxCode(Json *json)
{
    return "021001";
}

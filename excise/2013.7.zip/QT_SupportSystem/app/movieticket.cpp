﻿#include "movieticket.h"

MovieTicket::MovieTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("5005,1001",
    {
                    this,
                    (CmdProcFun)&MovieTicket::ExecuteCharge,
                    "电影票"
                });
}

QString MovieTicket::ExecuteCharge(Json *json)
{
    return OrderSubmit(json);
}

QString MovieTicket::GetChargeMoney(Json *json)
{
    return json->GetString("header.money");
}

QString MovieTicket::GetChargeTxCode(Json *json)
{
    return "018009";
}

QString MovieTicket::ParseOrderSubmit(QString returnStr)
{
    Json *vJson;
    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command","5005");
    AddXMLParam("operate","1001");

    if(returnStr=="")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success","1");
    }
    delete vJson;
    return GetReturnXML();
}


QString MovieTicket::OrderSubmit(Json *json)
{
    ClearBodys();
    SetHeadContacter(json->GetString("header.phone"));
    this->json->SetValue("CTSReqHeader.TranCode","018009");
      this->json->SetValue("CTSReqBody.foretellId",json->GetString("header.foretellId"));
      this->json->SetValue("CTSReqBody.count",json->GetString("header.count"));
      this->json->SetValue("CTSReqBody.prices",json->GetString("header.prices"));
      this->json->SetValue("CTSReqBody.fees",json->GetString("header.fees"));
      this->json->SetValue("CTSReqBody.rk",json->GetString("header.rk"));
      this->json->SetValue("CTSReqBody.orderId",json->GetString("header.orderId"));
      this->json->SetValue("CTSReqBody.cinemaName",json->GetString("header.cinemaName"));
      this->json->SetValue("CTSReqBody.showdate",json->GetString("header.showdate"));
      this->json->SetValue("CTSReqBody.showtime",json->GetString("header.showtime"));

    strSuccessMsg="您已经成功购买电影票，谢谢！";
    return ParseOrderSubmit(RequestInterface(GetReqString()));
}

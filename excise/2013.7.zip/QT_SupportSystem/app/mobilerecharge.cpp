﻿#include "mobilerecharge.h"

MobileRecharge::MobileRecharge(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("10,10",{
                    this,
                    (CmdProcFun)&MobileRecharge::QueryMobileUseJson,
                    "手机充值可用面额"
                });

    context = new MobileQueryContext();
    conv = new Converter();
    InitPrintInfo();

}


QString MobileRecharge::QueryMobileUseJson(Json *json)
{
    QString jsonstr;

    QString mobileNum=json->GetString("header.mobile");

    SetTxHeader("easytootest",config->Get_Union_TerminalID(), "11", "123123123","123", GetOrigSender());
    this->json->SetValue("CTSReqHeader.TranCode","005018");
    this->json->SetValue("CTSReqBody.mobilenum",mobileNum);
    jsonstr = RequestInterface(GetReqString());
    return ParseQueryResult(jsonstr);
}




bool MobileRecharge::PreCharge(Json *json)
{
    return true;
}

bool MobileRecharge::PostCharge(Json *json)
{
    return true;
}


QString MobileRecharge::ExecuteCharge(Json *json)
{
    QString mobile,amount,payType;
    QString result;
    mobile = json->GetString("header.mobile");
    amount = json->GetString("header.amount");
    payType = json->GetString("header.payType");


    ClearBodys();
    json->SetValue("CTSReqHeader.TranCode",context->hash.value(amount));
    json->SetValue("CTSReqBody.game_userid",mobile);
    json->SetValue("CTSReqBody.cardnum",QString::number(amount.toInt() / 50));
    json->SetValue("CTSReqBody.cardid",context->CardType);
    json->SetValue("CTSReqBody.game_area","");
    json->SetValue("CTSReqBody.game_srv","");
    json->SetValue("CTSReqBody.ret_url","");
    json->SetValue("CTSReqBody.version","4.0");
    strSuccessMsg = "您已成功为手机：" + mobile + " 充值 " + amount + " 元";
    context->DirectRechargeJson = RequestInterface(GetReqString());
    InitPrintInfo();
    SetBasePrintInfo("充值" + amount + "元","005008",amount + "元","NOW",mobile);
    result = ParseDirectRechargeResult(context->DirectRechargeJson);
    return result;

}

QString MobileRecharge::GetChargeMoney(Json *json)
{
    return json->GetString("header.amount");
}

QString MobileRecharge::GetChargeTxCode(Json *json)
{
    return context->hash.value(json->GetString("header.amount"));
}



QString MobileRecharge::ParseQueryResult(QString returnStr)
{
    Json *vJson;
    QDomElement vNode;
    QString ctype;
    context->ClearHash();
    ReInitXMLDoc();

    Common::WriteDebug("分析返回结果：");
    AddXMLParam("command","10");
    AddXMLParam("operate","10");

    if (returnStr == "")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障");
    }
    else
    {
        vJson = new Json(returnStr);
        if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
        {
            AddXMLParam("success","1");
            AddXMLParam("errormsg","");
            AddXMLParam("area",vJson->GetString("CTSRespBody.area"));
            AddXMLParam("cardtype",vJson->GetString("CTSRespBody.cardtype"));
            ctype = vJson->GetString("CTSRespBody.cardtype");
            if(ctype.contains("电信"))
            {
                context->CardType = "18";
            }
            else
            {
                context->CardType="140101";
            }

            if(vJson->GetString("CTSRespBody.cards.card")!="")
            {
                if(vJson->GetType("CTSRespBody.cards.card") == "JSON_OBJECT")
                {
                    vNode = AddXMLList();
                    if(vNode.isNull()==false)
                    {
                        AddXMLListAttribute(vNode,"id",vJson->GetString("CTSRespBody.cards.card.id"));
                        AddXMLListAttribute(vNode, "facevalue", vJson->GetString("CTSRespBody.cards.card.facevalue"));
                        AddXMLListAttribute(vNode, "saleprice", vJson->GetString("CTSRespBody.cards.card.saleprice"));
                        context->hash.insert(vJson->GetString("CTSRespBody.cards.card.facevalue"),vJson->GetString("CTSRespBody.cards.card.id"));
                    }
                }
                else if(vJson->GetType("CTSRespBody.cards.card") == "JSON_LIST")
                {
                    int count=vJson->GetCount("CTSRespBody.cards.card");
                    int i;
                    QString jsonstr;
                    Json *json;
                    for(i=0;i<count;i++)
                    {
                        jsonstr = vJson->GetJson("CTSRespBody.cards.card",i);
                        json = new Json(jsonstr);
                        vNode = AddXMLList();
                        if(vNode.isNull()==false)
                        {
                            AddXMLListAttribute(vNode,"id",json->GetString("id"));
                            AddXMLListAttribute(vNode, "facevalue", json->GetString("facevalue"));
                            AddXMLListAttribute(vNode, "saleprice", json->GetString("saleprice"));
                            context->hash.insert(vJson->GetString("facevalue"),json->GetString("id"));
                        }
                        delete json;
                    }
                }
            }
        }
        else
        {
            AddXMLParam("success","0");
            AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));

        }
        delete vJson;
    }

    return GetReturnXML();

}


QString MobileRecharge::ParseDirectRechargeResult(QString returnStr)
{
    Json *json;

    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command","10");
    AddXMLParam("operate","11");
    if(returnStr.isNull() || returnStr.isEmpty())
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode("00000000");
        return GetReturnXML();
    }

    json = new Json(returnStr);
    if(json->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode("00000001");
        return GetReturnXML();
    }

    if(json->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",json->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode(json->GetString("CTSRespHeader.MesgRefID"));
    }
    delete json;
    return GetReturnXML();
}



void MobileRecharge::InitPrintInfo()
{
}

void MobileRecharge::SetBasePrintInfo(QString businessType,QString tranCode,QString tranMoney,QString tranTime,QString mobile)
{
}

void MobileRecharge::SetPrintInfoSystemCode(QString systemCode)
{
}

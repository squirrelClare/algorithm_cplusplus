#include "onlinemall.h"

OnlineMall::OnlineMall(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("6000,1001",
    {
                    this,
                    (CmdProcFun)&OnlineMall::QueryShopCategory,
                    "查询商城物品分类"
                });
    map->insert("6000,1002",
    {
                    this,
                    (CmdProcFun)&OnlineMall::QueryShopHomepageInfo,
                    "查询商城主页信息"
                });
    map->insert("6000,1003",
    {
                    this,
                    (CmdProcFun)&OnlineMall::QueryShopProductInfo,
                    "查询商城物品信息"
                });
    map->insert("6000,1004",
    {
                    this,
                    (CmdProcFun)&OnlineMall::BuyProduct,
                    "购买商城物品"
                });

}

QString OnlineMall::QueryShopCategory(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(), "11","132123",GetQueryMesgRefID(), GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","012006");
    this->json->SetValue("CTSReqBody.id",json->GetString("header.id"));
    return ParseQueryShopCategory(RequestInterface(GetReqString()));
}

QString OnlineMall::QueryShopHomepageInfo(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(), "11","132123",GetQueryMesgRefID(), GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","012007");
    this->json->SetValue("CTSReqBody.numberOne",json->GetString("header.numberOne"));
    this->json->SetValue("CTSReqBody.numberTwo",json->GetString("header.numberTwo"));
    return ParseShopHomePageInfo(RequestInterface(GetReqString()));

}

QString OnlineMall::QueryShopProductInfo(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(), "11","132123",GetQueryMesgRefID(), GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","012001");
    this->json->SetValue("CTSReqBody.id",json->GetString("header.id"));
    this->json->SetValue("CTSReqBody.cateId",json->GetString("header.cateId"));
    this->json->SetValue("CTSReqBody.startId",json->GetString("header.startId"));
    this->json->SetValue("CTSReqBody.pageNum",json->GetString("header.pageNum"));
    return ParseShopProductInfo(RequestInterface(GetReqString()));
}


QString OnlineMall::ExecuteCharge(Json *json)
{
    return BuyProduct(json);
}

QString OnlineMall::GetChargeMoney(Json *json)
{
    return json->GetString("header.totalamount");
}

QString OnlineMall::GetChargeTxCode(Json *json)
{
    return "012002";
}

QString OnlineMall::ParseQueryShopCategory(QString returnStr)
{
    Json *vJson;
    Json *json;
    QDomElement vNode;
    AddXMLParam("command","6000");
    AddXMLParam("operate","1001");
    Common::SaveToFile("test.txt",returnStr);

    if(returnStr=="")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success","1");
        vNode = getParamsNode();
        json = new Json(vJson->GetString("CTSRespBody.sortInfos"));
        GetShopCategory(json,vNode,1);
        return GetReturnXML();
    }
    else
    {
        AddXMLParam("successs","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        return GetReturnXML();
    }

}

QString OnlineMall::ParseShopHomePageInfo(QString returnStr)
{
    Json* vJson;

    AddXMLParam("command","6000");
    AddXMLParam("operate","1002");
    if(returnStr=="")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success","1");

    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));

    }
    return GetReturnXML();
}


QString OnlineMall::BuyProduct(Json *json)
{
    Json* item;
    Json* newItem;
    ClearBodys();

    this->json->SetValue("CTSReqHeader.TranCode","012002");
    this->json->SetValue("CTSReqBody.receTel",json->GetString("header.receTel"));
    this->json->SetValue("CTSReqBody.totalamount",json->GetString("header.totalamount"));

    int count=json->GetCount("body.lists");
    for(int i=0;i<count;i++)
    {
        item = new Json(json->GetJson("body.lists",i));
        newItem = new Json();
        newItem->SetValue("productId",item->GetString("productId"));
        newItem->SetValue("acount",item->GetString("acount"));
        newItem->SetValue("price",item->GetString("price"));
        newItem->SetValue("properties",item->GetString("properties"));
        this->json->AddJson("CTSReqBody.orders",*newItem);
    }

    strSuccessMsg="交易成功，您已为成功购买商品！ 本次消费金额为:" + json->GetString("header.totalamount") + "元";

    return ParseBuyProduct(RequestInterface(GetReqString()));

}


void OnlineMall::GetShopCategory(Json *json, QDomElement node, int level)
{
    Json* item;
    QDomElement vNode;
}


QString OnlineMall::ParseBuyProduct(QString returnStr)
{
    Json *vJson;
    Json *item;

    srvsuccess = true;
    ReInitXMLDoc();
    AddXMLParam("command","6000");
    AddXMLParam("operate","1004");

    if(returnStr == "")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success","1");

    }
    return GetReturnXML();
}


QString OnlineMall::ParseShopProductInfo(QString returnStr)
{
}

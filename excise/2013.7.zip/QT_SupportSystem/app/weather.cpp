﻿#include "weather.h"

Weather::Weather(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("3000,1001",
    {
                    this,
                    (CmdProcFun)&Weather::SendWeather,
                    "查询天气"
                });

    downloaded = false;
}

QString Weather::QueryWeather(QString areaCode, QString term)
{
    ClearBodys();
    SetHeadOrigSender(term+",21218CCA77804D2BA1922C33E0151105");
    this->json->SetValue("CTSReqHeader.TranCode","011013");
    this->json->SetValue("CTSReqHeader.Userid","1.0");
    this->json->SetValue("CTSReqBody.theCityCode",areaCode);
    return ParseWeatherInfo(RequestInterface(GetReqString()));
}

QString Weather::DownWeatherData(QString areaID)
{
    if(downloaded)
    {
        return Common::LoadFromFile("Weather.xml");
    }
    else
    {
        QString result=QueryWeather(areaID,this->machineInfo->MachineId);
        QDomDocument xmlDoc;
        QDomNode node;
        QString xmlStr="";
        QDomNode vNode;

        if(result!="")
        {
            if(xmlDoc.setContent(result))
            {
                node = xmlDoc.createElement("string");
                QDateTime d = QDateTime::currentDateTime();
                node.appendChild(xmlDoc.createTextNode(d.toString("dddd")));
                xmlDoc.firstChildElement().insertBefore(node,xmlDoc.firstChildElement().firstChildElement());
                node = xmlDoc.firstChildElement();
                xmlStr="<root><params command=\"3000\" operate=\"1001\">";
                for(int i=0;i<node.childNodes().count();i++)
                {
                    vNode = node.childNodes().at(i);
                    if(i==5)
                    {
                        QString c = vNode.toElement().text();
                        if(c.indexOf("℃")>0)
                        {
                            xmlStr += "<string><![CDATA[" + c.mid(c.indexOf("℃")-2,3) + "]]></string>";
                        }

                    }
                    else
                    {
                        xmlStr += "<string><![CDATA[" + vNode.toElement().text() + "]]></string>";
                    }
                }
                xmlStr += "</params></root>";
                Common::SaveToFile("Weather.xml",xmlStr);
                downloaded=true;
            }
        }

        return xmlStr;
    }

}

QString Weather::SendWeather(Json *json)
{
    QString result="";
    result = DownWeatherData(json->GetString("header.AreaCode"));
    if(result != "1")
    {

    }
    return result;
}

QString Weather::ParseWeatherInfo(QString returnStr)
{
    Json* json;
    if(returnStr=="")
    {
        return "";
    }
    else
    {
        json = new Json(returnStr);
        if(json->GetString("CTSRespHeader.ResultCode")=="CTS0000")
        {
            return json->GetString("CTSRespBody.weatherInfo");
        }
        else
        {
            return "";
        }
    delete json;
    }
}

#ifndef MOBILEQUERYCONTEXT_H
#define MOBILEQUERYCONTEXT_H
#include<QString>
#include <QHash>
class MobileQueryContext
{
public:
    MobileQueryContext();
    QString DirectRechargeJson;
    QString QueryReturnJson;
    QString CardType;
    QHash<QString,QString> hash;
    void ClearHash();
};

#endif // MOBILEQUERYCONTEXT_H

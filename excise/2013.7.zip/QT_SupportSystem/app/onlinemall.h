#ifndef ONLINEMALL_H
#define ONLINEMALL_H
#include <QString>
#include "json.h"
#include "tradebase.h"
class OnlineMall : public TradeBase
{
public:
    OnlineMall(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString QueryShopCategory(Json *json);
    QString QueryShopHomepageInfo(Json *json);
    QString QueryShopProductInfo(Json *json);
    QString BuyProduct(Json *json);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);

private:
    QString ParseQueryShopCategory(QString returnStr);
    QString ParseShopHomePageInfo(QString returnStr);
    QString ParseShopProductInfo(QString returnStr);
    QString ParseBuyProduct(QString returnStr);
    void GetShopCategory(Json* json,QDomElement node,int level);

    void SetOrderNo(QString orderNo);

};

#endif // ONLINEMALL_H

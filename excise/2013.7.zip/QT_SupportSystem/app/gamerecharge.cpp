﻿#include "gamerecharge.h"



GameRecharge::GameRecharge(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("13,10",
    {
                    this,
                    (CmdProcFun)&GameRecharge::QueryGameCategory,
                    "查询游戏分类"
                });

    map->insert("13,11",
    {
                    this,
                    (CmdProcFun)&GameRecharge::QueryGameCardInfo,
                    "查询游戏卡信息"
                });
    map->insert("13,12",
    {
                    this,
                    (CmdProcFun)&GameRecharge::QueryGameAreaServer,
                    "查询游戏区域"
                });
    map->insert("13,14",
    {
                    this,
                    (CmdProcFun)&GameRecharge::QueryGameCardNumber,
                    "查询卡号"
                });

}

QString GameRecharge::ParseQueryGameCategory(QString returnStr)
{
    Json* vJson;
    QDomElement vNode;
    Json* item;
    QString result;

    ReInitXMLDoc();
    AddXMLParam("command","13");
    AddXMLParam("operate","10");
    if(returnStr=="")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        int count=vJson->GetCount("CTSRespBody.game");
        int i;
        for(i=0;i<count;i++)
        {
            item = new Json(vJson->GetJson("CTSRespBody.game",i));
            vNode = AddXMLList();
            if(vNode.isNull()==false)
            {
                AddXMLListAttribute(vNode,"gameid",item->GetString("gameid"));
                AddXMLListAttribute(vNode,"gamename",item->GetString("gamename"));

            }
            delete item;
        }
        result = GetReturnXML();
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        result = GetReturnXML();
    }
    delete vJson;
    return result;
}

QString GameRecharge::ParseQueryGameAreaServer(QString returnStr)
{
    Json* vJson;
    QDomElement vNode;
    Json* item;
    QString result;

    ReInitXMLDoc();
    AddXMLParam("command","13");
    AddXMLParam("operate","12");

    if(returnStr=="")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success","1");
        if(vJson->GetType("CTSRespBody.ROW")=="JSON_OBJECT")
        {
            item = new Json(vJson->GetString("CTSRespBody.ROW"));
            if(item->GetString("AREA")!="" && item->GetString("SERVER")!="")
            {
                vNode=AddXMLList();

                AddXMLListAttribute(vNode,"gameid",item->GetString("GAMEID"));
                AddXMLListAttribute(vNode,"gamename",item->GetString("GAMENAME"));
                AddXMLListAttribute(vNode,"area",item->GetString("AREA"));
                AddXMLListAttribute(vNode,"server",item->GetString("SERVER"));
            }
       delete item;
        }
        else if(vJson->GetType("CTSRespBody.ROW")=="JSON_LIST")
        {
            int count=vJson->GetCount("CTSRespBody.card");
            for(int i=0;i<count;i++)
            {
                item = new Json(vJson->GetJson("CTSRespBody.ROW",i));
                if(item->GetString("AREA")!="" && item->GetString("SERVER")!="")
                {
                    vNode=AddXMLList();

                    AddXMLListAttribute(vNode,"gameid",item->GetString("GAMEID"));
                    AddXMLListAttribute(vNode,"gamename",item->GetString("GAMENAME"));
                    AddXMLListAttribute(vNode,"area",item->GetString("AREA"));
                    AddXMLListAttribute(vNode,"server",item->GetString("SERVER"));
                }
                delete item;
            }

        }
        result = GetReturnXML();
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        result = GetReturnXML();
    }
    delete vJson;
    return result;

}


QString GameRecharge::GetChargeMoney(Json *json)
{
    return json->GetString("header.totalamount");
}

QString GameRecharge::GetChargeTxCode(Json *json)
{
    return json->GetString("header.cardid");
}


QString GameRecharge::QueryGameAreaServer(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123123",GetQueryMesgRefID(),GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","005016");
    this->json->SetValue("CTSReqBody.gameid",json->GetString("header.gameid"));
    this->json->SetValue("CTSReqBody.gamename",json->GetString("header.gamename"));
    return ParseQueryGameAreaServer(RequestInterface(GetReqString()));

}

QString GameRecharge::QueryGameCardInfo(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123123",GetQueryMesgRefID(),GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","005020");
    this->json->SetValue("CTSReqBody.gameid",json->GetString("header.gameid"));
    this->json->SetValue("CTSReqBody.gamename",json->GetString("header.gamename"));
    return ParseQueryGameCardInfo(RequestInterface(GetReqString()));
}

QString GameRecharge::QueryGameCardNumber(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123123",GetQueryMesgRefID(),GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","005004");
    this->json->SetValue("CTSReqBody.cardid",json->GetString("header.cardid"));
    this->json->SetValue("CTSReqBody.version","4.0");
    return ParseGameCardNum(RequestInterface(GetReqString()));
}

QString GameRecharge::ExecuteCharge(Json *json)
{
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode",json->GetString("header.cardid"));
    this->json->SetValue("CTSReqBody.cardid",json->GetString("header.cardid"));
    this->json->SetValue("CTSReqBody.cardnum",json->GetString("header.cardnum"));
    this->json->SetValue("CTSReqBody.game_userid",json->GetString("header.gameaccount"));
    this->json->SetValue("CTSReqBody.game_area",json->GetString("header.gamearea"));
    this->json->SetValue("CTSReqBody.game_srv",json->GetString("header.gamesrv"));
    this->json->SetValue("CTSReqBody.version","4.0");

    strSuccessMsg = "交易成功，您已为游戏帐户:"+ json->GetString("header.gameaccount") + " 成功充值 " + json->GetString("header.totalamount") + " 元！";
    InitPrintInfo();
    //SetBasePrintInfo();
    return ParseGameDirectRecharge(RequestInterface(GetReqString()));

}


QString GameRecharge::QueryGameCategory(Json *json)
{
    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123123",GetQueryMesgRefID(),GetOrigSender());
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","005019");
    this->json->SetValue("CTSReqBody.firstletter",json->GetString("header.firstletter"));
    this->json->SetValue("CTSReqBody.gameType",json->GetString("header.gameType"));
    return ParseQueryGameCategory(RequestInterface(GetReqString()));

}


QString GameRecharge::ParseQueryGameCardInfo(QString returnStr)
{
    Json* vJson;
    QDomElement vNode;
    Json* item;
    QString result;

    ReInitXMLDoc();
    AddXMLParam("command","13");
    AddXMLParam("operate","11");

    if(returnStr=="")
    {
        AddXMLParam("success","1");
        AddXMLParam("errormsg","网络故障");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        if(vJson->GetType("CTSRespBody.card")=="JSON_OBJECT")
        {
            vNode=AddXMLList();
            AddXMLListAttribute(vNode,"cardid",vJson->GetString("CTSRespBody.card.cardid"));
            AddXMLListAttribute(vNode,"petvalue",vJson->GetString("CTSRespBody.card.petvalue"));
            AddXMLListAttribute(vNode,"cardname",vJson->GetString("CTSRespBody.card.cardname"));
            AddXMLListAttribute(vNode,"saleprice",vJson->GetString("CTSRespBody.card.saleprice"));

        }
        else if(vJson->GetType("CTSRespBody.card")=="JSON_LIST")
        {
            int count=vJson->GetCount("CTSRespBody.card");
            for(int i=0;i<count;i++)
            {
                vNode=AddXMLList();
                item = new Json(vJson->GetJson("CTSRespBody.card",i));
                AddXMLListAttribute(vNode,"cardid",item->GetString("cardid"));
                AddXMLListAttribute(vNode,"petvalue",item->GetString("petvalue"));
                AddXMLListAttribute(vNode,"cardname",item->GetString("cardname"));
                AddXMLListAttribute(vNode,"saleprice",item->GetString("saleprice"));
                delete item;
            }
        }
        result = GetReturnXML();
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        result = GetReturnXML();
    }
    delete vJson;
    return result;

}

QString GameRecharge::ParseGameDirectRecharge(QString returnStr)
{
    Json* vJson;
    Json* item;

    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command","13");
    AddXMLParam("operate","13");

    if(returnStr=="")
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode("00000000");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode("00000001");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success","1");
        SetPrintInfoSystemCode(vJson->GetString("CTSRespHeader.MesgRefID"));
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    delete vJson;
    return GetReturnXML();


}

QString GameRecharge::ParseGameCardNum(QString returnStr)
{
    Json* vJson;
    Json* item;
    QDomElement vNode;
    QString result;

    ReInitXMLDoc();
    AddXMLParam("command","13");
    AddXMLParam("operate","14");

    if(returnStr=="")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","网络故障,操作失败");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg","协议错误，或网络故障");
        result = GetReturnXML();
    }
    else
    {
        if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
        {
            AddXMLParam("success", "1");
            AddXMLParam("innum", vJson->GetString("CTSRespBody.ret_cardinfos.card.innum"));
            AddXMLParam("amounts", vJson->GetString("CTSRespBody.ret_cardinfos.card.amounts"));
            result = GetReturnXML();
        }
        else
        {
            AddXMLParam("success","0");
            AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
            result = GetReturnXML();
        }
    }
    delete vJson;
    return result;

}

void GameRecharge::InitPrintInfo()
{
}

void GameRecharge::SetBasePrintInfo(QString businessType, QString tranCode, QString tranMoney, QString tranTime, QString nameOfGame, QString User)
{
}

void GameRecharge::SetPrintInfoSystemCode(QString systemCode)
{
}

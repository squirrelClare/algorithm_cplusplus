#include "comanylist.h"

ComanyList::ComanyList(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("5001,1001",
    {
                    this,
                    (CmdProcFun)&ComanyList::QueryNotice,
                    "查询物业通知"
                });
    map->insert("5001,1002",
    {
                    this,
                    (CmdProcFun)&ComanyList::QueryCompanyList,
                    "查询物业公司列表"
                });

    map->insert("5001,1003",
    {
                    this,
                    (CmdProcFun)&ComanyList::QueryIntro,
                    "查询物业公司介绍"
                });

    this->machineInfo = machineInfo;
    this->db = db;
}

QString ComanyList::QueryNotice(Json *json)
{
    QString sql;
    QSqlQuery query;
    QSqlRecord rs;

    QDomElement vNode;
    ReInitXMLDoc();
    AddXMLParam("command","5001");
    AddXMLParam("operate","1001");

    sql = "select title,content, from_unixtime(update_time) as uptime from et_mansion_notice where mansion_id="+ QString::number(machineInfo->MansionId) + "";
    if(db->QuerySQL(sql,&query))
    {
        AddXMLParam("success","1");
        while(query.next())
        {
        rs = query.record();
        vNode = AddXMLList();

        AddXMLListAttribute(vNode,"title",rs.field("title").value().toString());
        AddXMLListAttribute(vNode,"content",rs.field("content").value().toString());
        AddXMLListAttribute(vNode,"uptime",rs.field("uptime").value().toString());
        }
    }
    return GetReturnXML();
}

QString ComanyList::QueryCompanyList(Json *json)
{
    QString sql;
    QSqlQuery query;
    QSqlRecord rs;
    QString result;
    QStringList floors;
    QDomElement vNode;
    QString str;

    ReInitXMLDoc();
    AddXMLParam("command","5001");
    AddXMLParam("operate","1002");

    sql = "select distinct floor from et_mansion_nameplate where mansion_id="+ QString::number(machineInfo->MansionId) + "";
    if(db->QuerySQL(sql,&query))
    {
        AddXMLParam("success","1");
        while(query.next())
        {
            rs=query.record();
            floors.append(rs.field("floor").value().toString());
        }
        query.clear();
        str="";
        vNode = AddXMLList();
        for(int i=0;i<floors.count();i++)
        {
            AddXMLListAttribute(vNode, "floor", floors[i]);
            sql="select floor,number,title,note from et_mansion_nameplate where mansion_id="+QString::number(machineInfo->MansionId)+" and floor="+floors[i];

            if(db->QuerySQL(sql,&query))
            {
                while(query.next())
                {
                    rs=query.record();
                    str += rs.field("number").value().toString() + "|" + rs.field("title").value().toString() + "|" + rs.field("note").value().toString() + ",";
                }
            }

            if(str!="")
            {
                str = str.left(str.length()-1);
            }
            AddXMLListAttribute(vNode,"str",str);


        }

    }
    return GetReturnXML();
}

QString ComanyList::QueryIntro(Json *json)
{
    QString sql;
    QSqlQuery query;
    QSqlRecord rs;
    QString result;
    QStringList floors;
    QDomElement vNode;
    QString path;
    QString desc;


    ReInitXMLDoc();

    AddXMLParam("command","5001");
    AddXMLParam("operate","1003");

    sql="select path from et_attachment where id in (select attachment_id from et_mansion where id=" + QString::number(machineInfo->MansionId) + ")";

    path = db->GetString(sql);

    sql="select description from et_mansion where id="+QString::number(machineInfo->MansionId);
    desc = db->GetString(sql);


    if(path!="")
    {
        AddXMLParam("success","1");
        AddXMLParam("path",path);
        AddXMLParam("desc",desc);
    }
    return GetReturnXML();
}


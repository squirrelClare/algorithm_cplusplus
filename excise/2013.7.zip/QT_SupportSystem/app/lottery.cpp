﻿#include "lottery.h"

Lottery::Lottery(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
}

QString Lottery::Recharge(Json *json)
{
    ClearBodys();
    flag="";
    this->json->SetValue("CTSReqHeader.TranCode","016009");
    this->json->SetValue("CTSReqBody.cardId",json->GetString("header.cardId"));
    this->json->SetValue("CTSReqBody.money",json->GetString("header.money"));

    strSuccessMsg="您已成功为账户充值:" + json->GetString("header.money") + "元";

    return ParseRecharge(RequestInterface(GetReqString()));
}

QString Lottery::DirectCharge(Json *json)
{
    Json* vJson;
    Json* item;
    QString list;
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","016001");
    this->json->SetValue("CTSReqBody.cardId",json->GetString("header.cardId"));
    this->json->SetValue("CTSReqBody.allMoney",json->GetString("CTSReqBody.allMoney"));
    this->json->SetValue("CTSReqBody.type","card");
    this->json->SetValue("CTSReqBody.Head.Transaction","0");
    this->json->SetValue("CTSReqBody.Head.Ver","1");
    this->json->SetValue("CTSReqBody.Head.ChannelID","72");
    int count=json->GetCount("body.lists");
    for(int i=0;i<count;i++)
    {
        vJson = new Json(json->GetJson("body.lists",i));
        item = new Json();
        item->SetValue("id",vJson->GetString("id"));
        item->SetValue("lType",vJson->GetString("lType"));
        item->SetValue("issue",vJson->GetString("issue"));
        item->SetValue("pType",vJson->GetString("pType"));
        item->SetValue("bType",vJson->GetString("bType"));
        item->SetValue("bs",vJson->GetString("bs"));
        item->SetValue("isAppend",vJson->GetString("isAppend"));
        item->SetValue("betCount",vJson->GetString("betCount"));
        item->SetValue("betMoney",vJson->GetString("betMoney"));
        list = vJson->GetString("Stake");
        item->AddList("Stake",list.split(";"));

        this->json->AddJson("CTSReqBody.EntityList",*item);
        delete vJson;
        delete item;
    }

    strSuccessMsg = "您的购彩订单已提交，请稍后留意短信通知！";

    return ParseDirectCharge(RequestInterface(GetReqString()));
}


QString Lottery::ParseRecharge(QString returnStr)
{
    Json* vJson;

    srvsuccess=true;

    ReInitXMLDoc();
    AddXMLParam("command","15");
    AddXMLParam("operate","10");

    if(returnStr=="")
    {
        AddXMLParam("success","1");

        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        flag = vJson->GetString("CTSRespBody.user.money");
        AddXMLParam("success","1");
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess = false;
    }
    delete vJson;
    return GetReturnXML();

}

QString Lottery::ParseDirectCharge(QString returnStr)
{
    Json* vJson;

    srvsuccess=true;

    ReInitXMLDoc();
    AddXMLParam("command","15");
    AddXMLParam("operate","11");

    if(returnStr=="")
    {
        AddXMLParam("success","1");

        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success","1");
    }
    else
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess = false;
    }
    delete vJson;
    return GetReturnXML();
}


QString Lottery::ExecuteCharge(Json *json)
{
    QString oper;
    oper=json->GetString("header.operate");
    if(oper=="11")
    {
        return DirectCharge(json);
    }
    else if(oper=="10")
    {
        return Recharge(json);
    }
    return "";
}

QString Lottery::GetChargeMoney(Json *json)
{
    return json->GetString("header.money");
}

QString Lottery::GetChargeTxCode(Json *json)
{
    return "016009";
}

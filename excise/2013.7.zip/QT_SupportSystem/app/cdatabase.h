#ifndef CDATABASE_H
#define CDATABASE_H
#include <QString>

class CDatabase
{
public:
    CDatabase();
    bool InitDatabase();
    bool InitDatabase2();
    bool ExecuteSQL(QString sql);
    bool ExecuteSQL2(QString sql);
    bool QuerySQL(QString sql);
    QString GetString(QString sql);
    int GetInteger(QString sql);

};

#endif // CDATABASE_H

#ifndef MOBILERECHARGE_H
#define MOBILERECHARGE_H
#include "converter.h"
#include "json.h"
#include "tradebase.h"
#include "debugger.h"
#include "mobilequerycontext.h"
#include <QString>
#include <QMap>

class MobileRecharge:public TradeBase
{
public:
    MobileRecharge(QMap<QString,CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString QueryMobileUseJson(Json *json);

    bool PreCharge(Json* json);
    bool PostCharge(Json* json);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);
private:
    Converter *conv;
    MobileQueryContext *context;
    QString ParseQueryResult(QString returnStr);
    QString ParseDirectRechargeResult(QString returnStr);
    void InitPrintInfo();
    void SetBasePrintInfo(QString businessType,QString tranCode,QString tranMoney,QString tranTime,QString mobile);
    void SetPrintInfoSystemCode(QString systemCode);


};
#endif // MOBILERECHARGE_H

#ifndef CREDITRECHARGE_H
#define CREDITRECHARGE_H
#include "tradebase.h"
#include "debugger.h"
#include "json.h"

#include<QString>

class CreditRecharge : public TradeBase
{
public:
    CreditRecharge(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);
private:
    QString CreditCharge(Json* json);
    QString ParseCreditCharge(QString returnStr);
};

#endif // CREDITRECHARGE_H

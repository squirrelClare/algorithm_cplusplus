#ifndef MOVIETICKET_H
#define MOVIETICKET_H
#include "debugger.h"
#include "tradebase.h"
#include "json.h"
#include <QString>

class MovieTicket : public TradeBase
{
public:
    MovieTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);

private:
    QString ParseOrderSubmit(QString returnStr);
    QString OrderSubmit(Json *json);


};

#endif // MOVIETICKET_H

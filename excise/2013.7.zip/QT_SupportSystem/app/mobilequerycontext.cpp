#include "mobilequerycontext.h"

MobileQueryContext::MobileQueryContext()
{

}

void MobileQueryContext::ClearHash()
{
    hash.clear();
}

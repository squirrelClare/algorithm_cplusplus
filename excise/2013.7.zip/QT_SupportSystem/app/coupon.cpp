﻿#include "coupon.h"

Coupon::Coupon(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{

    map->insert("9000,011002",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011002,
                    "011002"
                });
    map->insert("9000,011003",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011003,
                    "011003"
                });
    map->insert("9000,011004",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011004,
                    "011004"
                });
    map->insert("9000,011011",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011011,
                    "011011"
                });
    map->insert("9000,011012",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011012,
                    "011012"
                });
    map->insert("9000,011013",
    {
                    this,
                    (CmdProcFun)&Coupon::Query011013,
                    "011013"
                });
    selectDetailDDUrlsets = "select * from ET_DDURLSET where COUPONID = %1";
    selectDDUrlsetWithOrConditionsPage = "select *  from ET_DDURLSET where (stateflag<>''1'') and imgsrc220 like %s and imgsrc100 like %1 and  showpic like %2 and TAGS like %3 and cityaddrlist like %4 order by siteurl desc,STARTDATE desc limit %5,%6";
    getDDUrlsetSum = "SELECT count(*) FROM ET_DDURLSET where (stateflag<>''1'') and imgsrc220 like %1 and imgsrc100 like %2 and  showpic like %3 and TAGS  like %4 and cityaddrlist like %5";
    getPingpai ="select city,imgsrc220,category,categorySub from ET_DDURLSET where categorySub in (select distinct(categorySub) from ET_DDURLSET)";
    getPingpaiyouhui ="select * from ET_DDURLSET where (stateflag<>''1'') and imgsrc220 like %1 and imgsrc100 like %2 and  showpic like %3 and categorySub = %4";
    createddclick = "CREATE TABLE if not exists et_ddmap_click (cid int(11) NOT NULL auto_increment,trancode varchar(30) default NULL,id varchar(30) default NULL,currtime varchar(30) default NULL, tag text,PRIMARY KEY  (cid)) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    insertddclicksql = "insert into et_ddmap_click (id,trancode,currtime,tag) values (%1,%2,%3,%4)";

    this->db = db;

}


void Coupon::InserDDClick(QString id, QString trancode, QString currtime, QString tag)
{
    //QString sql;
    //sql=insertddclicksql.arg(id).arg(trancode).arg(currtime).arg(tag);
    //Database.ExecuteSQL(sql);

}


Coupon::~Coupon()
{
}

QString Coupon::Query011002(Json *json)
{

    QDomDocument xmlDoc;
    QDomElement node;
    Json *vJson,*vItem;
    if(xmlDoc.setContent(Common::LoadFromFile("dd_category.xml")))
    {
      vJson=new Json();
      vJson->SetValue("CTSRespHeader.TranCode","011002");
      vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
      vJson->SetValue("CTSRespHeader.Channel","");
      vJson->SetValue("CTSRespHeader.MesgRefID","");
      vJson->SetValue("CTSRespHeader.OrigSender","");
      vJson->SetValue("CTSRespHeader.Userid","");
      vJson->SetValue("CTSRespHeader.Comment","");
      vJson->SetValue("CTSRespHeader.TxAccount","");
      vJson->SetValue("CTSRespHeader.TxAmt","");
      vJson->SetValue("CTSRespHeader.Contacter","");

      for(int i=0;i<xmlDoc.firstChildElement().childNodes().count();i++)
      {
          node = xmlDoc.firstChildElement().childNodes().at(i).toElement();
          vItem = new Json();
          vItem->SetValue("parent",node.firstChildElement().childNodes().at(0).toElement().text());
          vItem->SetValue("son",node.firstChildElement().childNodes().at(1).toElement().text());
          vJson->AddJson("CTSRespBody.data",*vItem);
          delete vItem;
      }
      AddXMLParam("command","9000");
      AddXMLParam("operate","011002");
      AddXMLParam("json",vJson->toString());
    delete vJson;
       return GetReturnXML();
    }
    else
    {
        return "";
    }

}

QString Coupon::Query011003(Json *json)
{
#if 0
    QDomDocument  xmlDoc;
    QDomElement nodeItem;
    QDomElement nodeData;
    Json *vJson,*vJson2,*vItem;
    QStringList circle;
    QStringList district;
    if(xmlDoc.setContent(Common::LoadFromFile("dd_city.xml")))
    {
        vJson=new Json();

        vJson->SetValue("CTSRespHeader.TranCode","011003");
        vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
        vJson->SetValue("CTSRespHeader.Channel","");
        vJson->SetValue("CTSRespHeader.MesgRefID","");
        vJson->SetValue("CTSRespHeader.OrigSender","");
        vJson->SetValue("CTSRespHeader.Userid","");
        vJson->SetValue("CTSRespHeader.Comment","");
        vJson->SetValue("CTSRespHeader.TxAccount","");
        vJson->SetValue("CTSRespHeader.TxAmt","");
        vJson->SetValue("CTSRespHeader.Contacter","");


        vJson2 = new Json();
        for(int i=0;i<xmlDoc.firstChildElement().childNodes().count();i++)
        {
            nodeData = xmlDoc.firstChildElement().childNodes().at(i).toElement();
            vItem = new Json();
            district.clear();
            circle.clear();
            for(int j=0;j<nodeData.firstChildElement().childNodes().count();j++)
            {


                nodeItem = nodeData.firstChildElement().childNodes().at(j).toElement();

                if(nodeItem.nodeName()=="district")
                {
                    district.append(nodeItem.text());
                }
                else if(nodeItem.nodeName()=="circle")
                {
                    circle.append(nodeItem.text());
                }
                else if(nodeItem.nodeName()=="city")
                {
                    vItem->SetValue("city",nodeItem.text());
                }
                else if(nodeItem.nodeName()=="cityNo")
                {
                    vItem->SetValue("cityNo",nodeItem.text());
                }
            }
            vItem->AddList("district",district);
            vItem->AddList("circle",circle);
            vJson2->AddJson("display",*vItem);
            vJson->AddJson("CTSRespBody.data",*vJson2);
            delete vItem;
        }

        AddXMLParam("command","9000");
        AddXMLParam("operate","011003");
        AddXMLParam("json",vJson->toString());
    delete vJson;
        delete vJson2;
        return GetReturnXML();
    }
    else
    {
        return "";
    }

#else
    return Common::LoadFromFile("011003.xml");
#endif
}

QString Coupon::Query011004(Json *json)
{
    Json *vJson;
    Json *shops;
    QString id,sql;
    QSqlQuery query;
    QSqlRecord rs;

    id=json->GetString("header.id");
    sql = selectDetailDDUrlsets.arg(id);
    vJson=new Json();

     vJson->SetValue("CTSRespHeader.TranCode","011004");
     vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
     vJson->SetValue("CTSRespHeader.Channel","");
     vJson->SetValue("CTSRespHeader.MesgRefID","");
     vJson->SetValue("CTSRespHeader.OrigSender","");
     vJson->SetValue("CTSRespHeader.Userid","");
     vJson->SetValue("CTSRespHeader.Comment","");
     vJson->SetValue("CTSRespHeader.TxAccount","");
     vJson->SetValue("CTSRespHeader.TxAmt","");
     vJson->SetValue("CTSRespHeader.Contacter","");

     if(db->QuerySQL(sql,&query))
     {
         if(query.next())
         {
             rs = query.record();
             vJson->SetValue("CTSRespBody.code","1");
            vJson->SetValue("CTSRespBody.citypic",rs.field("showpic").value().toString());
            vJson->SetValue("CTSRespBody.df_id","");
            vJson->SetValue("CTSRespBody.dis_7_download","");
            vJson->SetValue("CTSRespBody.dis_checkcode",rs.field("checkcode").value().toString());
            vJson->SetValue("CTSRespBody.dis_city",rs.field("city").value().toString());
            vJson->SetValue("CTSRespBody.dis_clicks",rs.field("clicks").value().toString());
            vJson->SetValue("CTSRespBody.dis_ctime","");
            vJson->SetValue("CTSRespBody.dis_desc",rs.field("demo").value().toString());
            vJson->SetValue("CTSRespBody.dis_detailInfo","");
            vJson->SetValue("CTSRespBody.dis_expdate",rs.field("expdate").value().toString());
            vJson->SetValue("CTSRespBody.dis_id",rs.field("couponid").value().toString());
            vJson->SetValue("CTSRespBody.dis_imgsrc",rs.field("showpic").value().toString());
            vJson->SetValue("CTSRespBody.dis_imgsrc100",rs.field("imgsrc100").value().toString());
            vJson->SetValue("CTSRespBody.dis_imgsrc220",rs.field("imgsrc220").value().toString());
            vJson->SetValue("CTSRespBody.dis_imgsrc568",rs.field("imgsrc568").value().toString());
            vJson->SetValue("CTSRespBody.dis_intro",rs.field("title").value().toString());
            vJson->SetValue("CTSRespBody.dis_isprint",rs.field("isprint").value().toString());
            vJson->SetValue("CTSRespBody.dis_isshow",rs.field("isshow").value().toString());
            vJson->SetValue("CTSRespBody.dis_issms",rs.field("issms").value().toString());
            vJson->SetValue("CTSRespBody.dis_isvirtual","");
            vJson->SetValue("CTSRespBody.dis_mdate",rs.field("modifydate").value().toString());
            vJson->SetValue("CTSRespBody.dis_place",rs.field("place").value().toString());
            vJson->SetValue("CTSRespBody.dis_printed",rs.field("printed").value().toString());
            vJson->SetValue("CTSRespBody.dis_qrimg",rs.field("qrimg").value().toString());
            vJson->SetValue("CTSRespBody.dis_relbrand","");
            vJson->SetValue("CTSRespBody.dis_startdate",rs.field("startdate").value().toString());
            vJson->SetValue("CTSRespBody.dis_tags",rs.field("tags").value().toString());
            vJson->SetValue("CTSRespBody.dis_title",rs.field("title").value().toString());
            vJson->SetValue("CTSRespBody.dorder","");
            vJson->SetValue("CTSRespBody.smsInfo","");
            shops = new Json(rs.field("cityaddrlist").value().toString());
            vJson->AddJson("CTSRespBody.merchants",*shops);
            delete shops;

         }
         else
         {
             vJson->SetValue("CTSRespBody.code","-1");
             vJson->SetValue("CTSRespBody.msg","查找不到优惠卷品牌信息");
         }

     }

     AddXMLParam("command","9000");
     AddXMLParam("operate","011004");
     AddXMLParam("json",vJson->toString());
    delete  vJson;

     return GetReturnXML();
}

QString Coupon::Query011005(Json *json)
{
    Json *vJson;
    Json *coupon;
    Json *url;
    Json *shops;

    QString keyword;
    QString cd;
    QString order;
    QString page;
    QString pageSize;
    QString center;
    QString x,y,cityAddrList;
    QString scope;
    QString start,sqllist,sqlcount;
    QString expdate;
    QSqlQuery query;
    QSqlRecord rs;

    int amount;
    int pages;
    bool bResult;

    keyword = json->GetString("header.keyword");
    keyword = "%" + keyword + "%";
    cd = "%iberry%bin%";
    order = json->GetString("header.order");
    page = json->GetString("header.page");
    pageSize = json->GetString("header.pagesize");
    center=json->GetString("header.center");
    center = "%" + center + "%";

    x=json->GetString("header.x");
    y=json->GetString("header.y");
    scope = json->GetString("header.scope");
    if(page=="")page="1";
    if(pageSize=="")pageSize="12";
    if(pageSize.toInt()>12)pageSize="12";
    if(x!="" && y!="")
    {
        if(x.length()>7)x=x.left(7);
        if(y.length()>7)y=y.left(6);
        cityAddrList = "%" + x + "%" + y + "%";
        pageSize ="12";
    }
    start =QString::number( (page.toInt()-1)*pageSize.toInt());
    sqllist = selectDDUrlsetWithOrConditionsPage.arg(cd,cd,cd,keyword,center,start,pageSize);
    sqlcount = getDDUrlsetSum.arg(cd,cd,cd,keyword,center);

    amount=db->GetInteger(sqlcount);
    pages =0;
    if(amount>0)
    {
        if(amount % pageSize.toInt() > 0)
        {
            pages = amount / pageSize.toInt() + 1;
        }
        else
        {
            pages = amount / pageSize.toInt();

        }
    }

    vJson = new Json();
    vJson->SetValue("CTSRespHeader.TranCode","011005");
    vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
    vJson->SetValue("CTSRespHeader.Channel","");
    vJson->SetValue("CTSRespHeader.MesgRefID","");
    vJson->SetValue("CTSRespHeader.OrigSender","");
    vJson->SetValue("CTSRespHeader.Userid","");
    vJson->SetValue("CTSRespHeader.Comment","");
    vJson->SetValue("CTSRespHeader.TxAccount","");
    vJson->SetValue("CTSRespHeader.TxAmt","");
    vJson->SetValue("CTSRespHeader.Contacter","");
    vJson->SetValue("CTSRespBody.pages",QString::number(pages));

    if(db->QuerySQL(sqllist,&query))
    {
        vJson->SetValue("CTSRespBody.code","1");
        while(query.next())
        {
            rs = query.record();
            expdate = rs.field("expdate").value().toString().replace("/","-");
            if(QDateTime::fromString(expdate) > QDateTime::currentDateTime())
            {
                coupon = new Json();
                coupon->SetValue("code","1");
                coupon->SetValue("citypic", rs.field("showpic").value().toString());
              coupon->SetValue("df_id", "");
              coupon->SetValue("dis_7_download", "");
              coupon->SetValue("dis_checkcode", rs.field("checkcode").value().toString());
              coupon->SetValue("dis_city", rs.field("city").value().toString());
              coupon->SetValue("dis_clicks", rs.field("clicks").value().toString());
              coupon->SetValue("dis_ctime", "");
              coupon->SetValue("dis_desc",rs.field("demo").value().toString().replace("\r\n",""));

              coupon->SetValue("dis_detailInfo", "");
              coupon->SetValue("dis_expdate", rs.field("expdate").value().toString());
              coupon->SetValue("dis_id", rs.field("couponid").value().toString());
              coupon->SetValue("dis_imgsrc", rs.field("showpic").value().toString());
              coupon->SetValue("dis_imgsrc100", rs.field("imgsrc100").value().toString());
              coupon->SetValue("dis_imgsrc220", rs.field("imgsrc220").value().toString());
              coupon->SetValue("dis_imgsrc568", rs.field("imgsrc568").value().toString());
              coupon->SetValue("dis_intro",rs.field("title").value().toString());
              coupon->SetValue("dis_isprint", rs.field("isprint").value().toString());
              coupon->SetValue("dis_isshow", rs.field("isshow").value().toString());
              coupon->SetValue("dis_issms", rs.field("issms").value().toString());
              coupon->SetValue("dis_isvirtual", "");
              coupon->SetValue("dis_mdate", rs.field("modifydate").value().toString());
              coupon->SetValue("dis_place", rs.field("place").value().toString());
              coupon->SetValue("dis_printed", rs.field("printed").value().toString());
              coupon->SetValue("dis_qrimg", rs.field("qrimg").value().toString());
              coupon->SetValue("dis_relbrand", "");
              coupon->SetValue("dis_startdate", rs.field("startdate").value().toString());
              coupon->SetValue("dis_tags", rs.field("tags").value().toString());
              coupon->SetValue("dis_title", rs.field("title").value().toString());
              coupon->SetValue("dorder", "");
              coupon->SetValue("smsInfo", "");

              url = new Json();
              url->AddJson("coupon",*coupon);
              url->SetValue("vCoupons","[]");

              shops = new Json(rs.field("cityaddrlist").value().toString());
              url->SetValue("merchantsCount",QString::number(url->toVariant().toList().count()));

                bResult=false;
                if(x!="" && y!="")
                {

                }

            }
        }
    }
    else
    {
        vJson->SetValue("CTSRespBody.code","-1");
        vJson->SetValue("CTSRespBody.msg","查找不到优惠卷品牌信息");
    }

    AddXMLParam("command","9000");
    AddXMLParam("operate","011005");
    AddXMLParam("json",vJson->toString());
    delete vJson;
    return GetReturnXML();

}

QString Coupon::Query011006(Json *json)
{
}

QString Coupon::Query011011(Json *json)
{
    QSqlQuery query;
    QSqlRecord rs;
    QString keyword,order,page,pagesize,center,x,y,scope,cityaddrlist;
    QString sql,sqlcount,start;
    int amount,pages,maxShop;
    Json *vJson,*url,*urls;
    bool boo;
    int i,j;
    QString expdate;

    vJson=new Json();
    vJson->SetValue("CTSRespHeader.TranCode","011011");
    vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
    vJson->SetValue("CTSRespHeader.Channel","");
    vJson->SetValue("CTSRespHeader.MesgRefID","");
    vJson->SetValue("CTSRespHeader.OrigSender","");
    vJson->SetValue("CTSRespHeader.Userid","");
    vJson->SetValue("CTSRespHeader.Comment","");
    vJson->SetValue("CTSRespHeader.TxAccount","");
    vJson->SetValue("CTSRespHeader.TxAmt","");
    vJson->SetValue("CTSRespHeader.Contacter","");


    if(db->QuerySQL(getPingpai,&query))
    {
        while(query.next())
        {
            rs=query.record();
            url=new Json();
            url->SetValue("cb_id",rs.field("categorySub").value().toString());
            url->SetValue("cb_name",rs.field("category").value().toString());
            url->SetValue("cb_img",rs.field("imgsrc220").value().toString());
            url->SetValue("cityno",rs.field("city").value().toString());
            vJson->AddJson("CTSRespBody.result",*url);
            delete url;
        }
    }

    AddXMLParam("command", "9000");
    AddXMLParam("operate", "011011");
    AddXMLParam("json", vJson->toString());
    delete vJson;
    return GetReturnXML();

}

QString Coupon::Query011013(Json *json)
{
    QSqlQuery uniQ;
    QString id,sql;
    int i;
    Json *vJson,*vJsonItem,*shops;
    id=json->GetString("header.id");
    vJson=new Json();
    vJson->SetValue("CTSRespHeader.TranCode","011013");
  vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
  vJson->SetValue("CTSRespHeader.Channel","");
  vJson->SetValue("CTSRespHeader.MesgRefID","");
  vJson->SetValue("CTSRespHeader.OrigSender","");
  vJson->SetValue("CTSRespHeader.Userid","");
  vJson->SetValue("CTSRespHeader.Comment","");
  vJson->SetValue("CTSRespHeader.TxAccount","");
  vJson->SetValue("CTSRespHeader.TxAmt","");
  vJson->SetValue("CTSRespHeader.Contacter","");

  AddXMLParam("command", "9000");
  AddXMLParam("operate", "011013");
  AddXMLParam("json", vJson->toString());
    delete vJson;
  return GetReturnXML();
}


QString Coupon::Query011012(Json *json)
{
    QSqlQuery query;
    QSqlRecord rs;
    QString totalRecords,pageSize,nextPage,brand,topage,sql,cd;
    Json *vJson,*resultList,*item;
    int i;

    cd="%iberry%bin%";
    vJson=new Json();

  vJson->SetValue("CTSRespHeader.TranCode","011012");
  vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
  vJson->SetValue("CTSRespHeader.Channel","");
  vJson->SetValue("CTSRespHeader.MesgRefID","");
  vJson->SetValue("CTSRespHeader.OrigSender","");
  vJson->SetValue("CTSRespHeader.Userid","");
  vJson->SetValue("CTSRespHeader.Comment","");
  vJson->SetValue("CTSRespHeader.TxAccount","");
  vJson->SetValue("CTSRespHeader.TxAmt","");
  vJson->SetValue("CTSRespHeader.Contacter","");

  sql = getPingpaiyouhui.arg(cd,cd,cd,json->GetString("header.brand"));
  if(db->QuerySQL(sql,&query))
  {

      int count=0;
      while(query.next())
      {
          rs=query.record();
          if(count==0)
          {
              brand = rs.field("category").value().toString();
              vJson->SetValue("CTSRespBody.infoMap.brandname",brand);
              vJson->SetValue("CTSRespBody.infoMap.pageinfo.pageSize","10");
              vJson->SetValue("CTSRespBody.infoMap.pageinfo.nextPage","-1");
          }
          count++;

          item = new Json();
          item->SetValue("id",rs.field("couponid").value().toString());
          item->SetValue("discount_rate","");
          item->SetValue("title",rs.field("title").value().toString());
          item->SetValue("clicks",rs.field("clicks").value().toString());
          item->SetValue("sortType","1");
          item->SetValue("image_small",rs.field("imgsrc100").value().toString());
          item->SetValue("image_large",rs.field("showpic").value().toString());
          vJson->AddJson("CTSRespBody.resultList",*item);
      }
      vJson->SetValue("CTSRespBody.infoMap.pageinfo.totalRecords",QString::number(count));
  }

  AddXMLParam("command", "9000");
  AddXMLParam("operate", "011012");
  AddXMLParam("json", vJson->toString());
delete vJson;
  return GetReturnXML();

}




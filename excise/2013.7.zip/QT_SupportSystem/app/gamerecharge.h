#ifndef GAMERECHARGE_H
#define GAMERECHARGE_H
#include "debugger.h"
#include<QString>
#include<QtXml>
#include "json.h"
#include "tradebase.h"
class GameRecharge:public TradeBase
{
public:

    GameRecharge(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;

private:
    QString ParseQueryGameCategory(QString returnStr);
    QString ParseQueryGameAreaServer(QString returnStr);
    QString ParseQueryGameCardInfo(QString returnStr);
    QString ParseGameDirectRecharge(QString returnStr);
    QString ParseGameCardNum(QString returnStr);

    void InitPrintInfo();
    void SetBasePrintInfo(QString businessType,QString tranCode,QString tranMoney,QString tranTime,QString nameOfGame,QString User);
    void SetPrintInfoSystemCode(QString systemCode);

public:
    QString QueryGameCategory(Json *json);
    QString QueryGameAreaServer(Json *json);
    QString QueryGameCardInfo(Json *json);
    QString QueryGameCardNumber(Json *json);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);
};

#endif // GAMERECHARGE_H

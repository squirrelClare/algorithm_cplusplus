﻿#ifndef PLANETICKET_H
#define PLANETICKET_H
#include "common.h"
#include "debugger.h"
#include "database.h"
#include "tradebase.h"
#include "converter.h"

#include<QString>
#include<QStringList>
#include<QDir>
#include<QDateTime>

class PlaneTicket : public TradeBase
{
public:
    PlaneTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    ~PlaneTicket();
    QString QuerycnAirCityList();
    QString QueryCarrier();
    QString QueryAirNumberUseJson(Json *json);
    QString QueryAirCabinUseJson(Json *json);
    QString OrderAirPlanUseJson(Json *json);
    QString NotifyPlayInfo();
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);
private:
    Converter *convertor;
    QString orderID;
    QString orderInfo;

    QStringList tempList;
    QString ParseQueryAirNumberReturn(QString returnStr);
    QString ParseOrderAirPlanReturn(QString returnStr);
    QString ParseNotifyPlayInfoReturn(QString returnStr);
    QString QueryAirNumberWithPrice(QString org,QString dst,QString airways,QString fltd);
    void InitPrintInfo();
    void SetBasePrintInfo(QString busstype, QString trancode,QString tranmoney,QString trantime);
    void SetPrintInfoSystemCode(QString  systemcode);
};
#endif // PLANETICKET_H

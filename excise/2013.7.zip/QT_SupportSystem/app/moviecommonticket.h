#ifndef MOVIECOMMONTICKET_H
#define MOVIECOMMONTICKET_H
#include "debugger.h"
#include "tradebase.h"
#include "json.h"
#include <QString>

class MovieCommonTicket : public TradeBase
{
public:
    MovieCommonTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);

private:
    QString ParseOrderSubmit(QString returnStr);
    QString OrderSubmit(Json *json);
};

#endif // MOVIECOMMONTICKET_H

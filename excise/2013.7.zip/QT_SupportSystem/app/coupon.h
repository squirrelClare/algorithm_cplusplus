﻿#ifndef COUPON_H
#define COUPON_H
#include<machineinfo.h>
#include<database.h>
#include<debugger.h>
#include<tradebase.h>
#include<QDir>
#include<QString>
#include <QStringList>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QSqlField>
#include <QtXml>

class Coupon : public TradeBase
{
private:
    QString selectDetailDDUrlsets;
    QString selectDDUrlsetWithOrConditionsPage;
    QString getDDUrlsetSum;
    QString getPingpai;
    QString getPingpaiyouhui;
    QString createddclick;
    QString insertddclicksql;

    Database *db;
    void InserDDClick(QString id,QString trancode,QString currtime,QString tag);
public:
    Coupon(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    ~Coupon();
    QString Query011002(Json *json);
    QString Query011003(Json *json);
    QString Query011004(Json *json);
    QString Query011005(Json *json);
    QString Query011006(Json *json);
    QString Query011011(Json *json);
    QString Query011012(Json *json);
    QString Query011013(Json *json);
};

#endif // COUPON_H

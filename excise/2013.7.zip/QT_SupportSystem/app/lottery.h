#ifndef LOTTERY_H
#define LOTTERY_H
#include<QString>

#include "json.h"
#include "tradebase.h"
class Lottery : public TradeBase
{
public:
    Lottery(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);
    QString Recharge(Json *json);
    QString DirectCharge(Json *json);
    QString ExecuteCharge(Json *json);
    QString GetChargeMoney(Json *json);
    QString GetChargeTxCode(Json *json);


private:
    QString ParseRecharge(QString returnStr);
    QString ParseDirectCharge(QString returnStr);




};

#endif // LOTTERY_H

﻿
#include "creditrecharge.h"

CreditRecharge::CreditRecharge(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("5002,1001",
    {
                    this,
                    (CmdProcFun)&CreditRecharge::ExecuteCharge,
                    "信用卡还款"
                });
}

QString CreditRecharge::ExecuteCharge(Json *json)
{
    return CreditCharge(json);
}

QString CreditRecharge::GetChargeMoney(Json *json)
{
    return json->GetString("header.money");
}

QString CreditRecharge::GetChargeTxCode(Json *json)
{
    return "008001";
}


QString CreditRecharge::CreditCharge(Json *json)
{

    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","008001");
    this->json->SetValue("CTSReqBody.creditcardno",json->GetString("header.creditcardno"));
    this->json->SetValue("CTSReqBody.creditcardbank",json->GetString("header.creditcardbank"));
    this->json->SetValue("CTSReqBody.money",json->GetString("header.money"));
    this->json->SetValue("CTSReqBody.mobile",json->GetString("header.mobile"));

    strSuccessMsg = "您已成功为信用卡: " + json->GetString("header.creditcardno") + " 还款 " + json->GetString("header.money") + "元";
    return ParseCreditCharge(RequestInterface(GetReqString()));
}

QString CreditRecharge::ParseCreditCharge(QString returnStr)
{
    Json *vJson;
    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command","5002");
    AddXMLParam("operate","1001");

    if(returnStr=="")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success","1");
    }
    delete vJson;
    return GetReturnXML();
}

﻿#include "planeticket.h"

PlaneTicket::PlaneTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("12,10",
    {
                    this,
                    (CmdProcFun)&PlaneTicket::QuerycnAirCityList,
                    "查询飞机票城市列表"
                });
    map->insert("12,11",
    {
                    this,
                    (CmdProcFun)&PlaneTicket::QueryCarrier,
                    "查询飞机票航空公司"
                });
    map->insert("12,12",
    {
                    this,
                    (CmdProcFun)&PlaneTicket::QueryAirNumberUseJson,
                    "查询飞机票航班信息"
                });
    map->insert("12,13",
    {
                    this,
                    (CmdProcFun)&PlaneTicket::QueryAirCabinUseJson,
                    "查询飞机票座位"
                });

}

PlaneTicket::~PlaneTicket()
{
}
QString PlaneTicket::QuerycnAirCityList()
{
    QString apppath;
    QString filepath;
    QString result;
    apppath=QDir::currentPath();
    filepath=apppath + "cnAirCityList.txt";
    return Common::LoadFromFile(filepath);
}

QString PlaneTicket::QueryCarrier()
{
    QString filepath;
    QString apppath;
    QString result;
    apppath=QDir::currentPath();
    filepath= apppath + "cnAirCompany.txt";
    return Common::LoadFromFile(filepath);
}

QString PlaneTicket::QueryAirNumberUseJson(Json *json)
{
    QString org;
    QString dst;
    QString airways;
    QString fltd;

    ClearBodys();
    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123132",GetQueryMesgRefID(),GetOrigSender());
    this->json->SetValue("CTSReqHeader.TranCode","015001");
    org=json->GetString("header.org");
    dst=json->GetString("header.dst");
    airways=json->GetString("header.airways");
    fltd=json->GetString("header.fltd");
    return QueryAirNumberWithPrice(org, dst, airways, fltd);
}

QString PlaneTicket::QueryAirCabinUseJson(Json *json)
{
    QString vJsonStr;
    Json *vJson;
    Json *item;
    QDomElement vNode;

     ReInitXMLDoc();
     AddXMLParam("command", "12");
     AddXMLParam("operate", "13");
     //vJsonStr=Context.CabinHash.getValue(json->GetString("header.line_number");

     if(vJsonStr == "")
     {
             AddXMLParam("success", "0");
             AddXMLParam("errormsg", "没有找到相关的纪录");
     }
     else
     {
             AddXMLParam("success", "1");
             vJson = new Json(vJsonStr);
             int num=vJson->GetCount(vJsonStr);
             for(int i=0;i<num;i++)
             {
                 item=new Json(vJson->GetJson(vJsonStr,i));
                 vNode=AddXMLList();
                 AddXMLListAttribute(vNode, "code", item->GetString("code"));
                 AddXMLListAttribute(vNode, "discount", item->GetString("discount"));
                 AddXMLListAttribute(vNode, "price", item->GetString("price"));
                 AddXMLListAttribute(vNode, "chdprice", item->GetString("chdprice"));
                 AddXMLListAttribute(vNode, "remain", item->GetString("remain"));
                 AddXMLListAttribute(vNode, "description", item->GetString("description"));
                 AddXMLListAttribute(vNode, "policyid", item->GetString("policyid"));
                 delete item;
             }
             delete vJson;
}
     return GetReturnXML();
}

QString PlaneTicket::OrderAirPlanUseJson(Json *json)
{
    ClearBodys();
    int i;
    Json* item;
    Json* item2;
    Json* lists;
    QString tempStr;

    SetTxHeader("easytootest",config->Get_Union_TerminalID(),"11","123132",GetQueryMesgRefID(),GetOrigSender());
    int count=json->GetCount("body.lists");
    for(int i=0;i<count;i++)
    {        
        item=new Json(json->GetJson("body.lists",i));

        if(item->GetString("pnode")=="oi")
        {
            this->json->SetValue("CTSReqBody.strXml.oi.allprice",item->GetString("allprice"));
            this->json->SetValue("CTSReqBody.strXml.oi.faul",item->GetString("faul"));
            this->json->SetValue("CTSReqBody.strXml.oi.build",item->GetString("build"));
            this->json->SetValue("CTSReqBody.strXml.oi.derate",item->GetString("derate"));
            this->json->SetValue("CTSReqBody.strXml.oi.ftype",item->GetString("ftype"));
            this->json->SetValue("CTSReqBody.strXml.oi.gtt",item->GetString("gtt"));
            this->json->SetValue("CTSReqBody.strXml.oi.sta",item->GetString("sta"));
            this->json->SetValue("CTSReqBody.strXml.oi.pt",item->GetString("pt"));
            this->json->SetValue("CTSReqBody.strXml.oi.tn",item->GetString("tn"));
        }
        else if(item->GetString("pnode")=="li")
        {
             this->json->SetValue("CTSReqBody.strXml.li.lnm",item->GetString("lnm"));
             this->json->SetValue("CTSReqBody.strXml.li.mobile",item->GetString("mobile"));
             this->json->SetValue("CTSReqBody.strXml.li.tel",item->GetString("tel"));
             this->json->SetValue("CTSReqBody.strXml.li.email",item->GetString("email"));
             this->json->SetValue("CTSReqBody.strXml.li.laddr",item->GetString("laddr"));
             this->json->SetValue("CTSReqBody.strXml.li.remark",item->GetString("remark"));
             this->json->SetValue("CTSReqBody.strXml.li.incname",item->GetString("incnameincname"));
        }
        else if(item->GetString("pnode")=="sails")
        {
            item2 = new Json();
            item2->SetValue("airways",item->GetString("airways"));
            item2->SetValue("fltno",item->GetString("fltno"));
            item2->SetValue("sc",item->GetString("sc"));
            item2->SetValue("ec",item->GetString("ec"));
            item2->SetValue("fdate",item->GetString("fdate"));
            item2->SetValue("stime",item->GetString("stime"));
            item2->SetValue("etime",item->GetString("etime"));
            item2->SetValue("pty",item->GetString("pty"));
            item2->SetValue("cabin",item->GetString("cabin"));
            item2->SetValue("pnr",item->GetString("pnr"));
            this->json->AddJson("CTSReqBody.strXml.sails",*item2);
            delete item2;
        }
        else if(item->GetString("pnode")=="cis")
        {
            item2 = new Json();
            item2->SetValue("cname",item->GetString("cname"));
            item2->SetValue("ctype",item->GetString("ctype"));
            item2->SetValue("cctype",item->GetString("cctype"));
            item2->SetValue("ccardno",item->GetString("ccardno"));
            item2->SetValue("buycnt",item->GetString("buycnt"));
            item2->SetValue("largessCnt",item->GetString("largessCnt"));
            item2->SetValue("tprice",item->GetString("tprice"));
            item2->SetValue("cfuel",item->GetString("cfuel"));
            item2->SetValue("cbuild",item->GetString("cbuild"));
            this->json->AddJson("CTSReqBody.strXml.cis",*item2);
            delete item2;
        }
        delete item;
    }
    InitPrintInfo();
    SetBasePrintInfo("飞机票","015004",this->json->GetString("header.totalamount"),QDateTime::currentDateTime().toString());

    strSuccessMsg = "交易成功，您已为成功订购机票！ 本次消费金额为: " + this->json->GetString("header.totalamount") + " 元！";

    return  ParseOrderAirPlanReturn(RequestInterface(GetReqString()));
}

QString PlaneTicket::NotifyPlayInfo()
{
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode","001006");
    this->json->SetValue("CTSReqBody.CMD","NotifyPay");
    this->json->SetValue("CTSReqBody.OrderId",this->orderID);
    this->json->SetValue("CTSReqBody.UserName","");
    this->json->SetValue("CTSReqBody.orderInfo",this->orderInfo);
    return ParseNotifyPlayInfoReturn(RequestInterface(GetReqString()));
}

QString PlaneTicket::ExecuteCharge(Json *json)
{
    return OrderAirPlanUseJson(json);
}

QString PlaneTicket::GetChargeMoney(Json *json)
{
      return json->GetString("header.totalamount");
}

QString PlaneTicket::GetChargeTxCode(Json *json)
{
    return "015004";
}

QString PlaneTicket::ParseQueryAirNumberReturn(QString returnStr)
{
    Json* vJson;
    Json* item;
    Json* cabinitem;
    QDomElement vNode;
    QDomElement vcabinNode;
    QDomDocument doc;


    ReInitXMLDoc();
    AddXMLParam("command", "12");
    AddXMLParam("operate", "12");

    if (returnStr.isEmpty())
    {
         AddXMLParam("success", "0");
         AddXMLParam("errormsg", "网络故障,操作失败");
         return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if (vJson->GetString("CTSRespHeader.ResultCode")=="CTS0000")
    {
        AddXMLParam("success", "1");
        AddXMLParam("startcity",vJson->GetString("CTSRespBody.startcity"));
        AddXMLParam("endcity",vJson->GetString("CTSRespBody.endcity"));
        AddXMLParam("startdate",vJson->GetString("CTSRespBody.startdate"));
        AddXMLParam("yprice",vJson->GetString("CTSRespBody.yprice"));
        int count=vJson->GetCount("CTSRespBody.date");
        for(int i=0;i<count;i++)
        {
            item = new Json(vJson->GetJson("CTSRespBody.date",i));
            vNode = AddXMLList();
            AddXMLListAttribute(vNode, "fltno", item->GetString("fltno"));
            AddXMLListAttribute(vNode, "sc", item->GetString("sc"));
            AddXMLListAttribute(vNode, "scAirdrome", item->GetString("scAirdrome"));
            AddXMLListAttribute(vNode, "ec", item->GetString("ec"));
            AddXMLListAttribute(vNode, "ecAirdrome", item->GetString("ecAirdrome"));
            AddXMLListAttribute(vNode, "deptime", item->GetString("deptime"));
            AddXMLListAttribute(vNode, "arrtime", item->GetString("arrtime"));
            AddXMLListAttribute(vNode, "planesty", item->GetString("planesty"));
            AddXMLListAttribute(vNode, "stopnum", item->GetString("stopnum"));
            AddXMLListAttribute(vNode, "etkt", item->GetString("etkt"));
            AddXMLListAttribute(vNode, "meal", item->GetString("meal"));
            int subcount=item->GetCount("classs");
            for(int j=0;j<subcount;j++)
            {
                cabinitem = new Json(item->GetJson("classs",j));
                vcabinNode=doc.createElement("cabin");
                AddXMLListAttribute(vcabinNode, "classname", cabinitem->GetString("classname"));
                AddXMLListAttribute(vcabinNode, "num", cabinitem->GetString("num"));
                AddXMLListAttribute(vcabinNode, "saleprice", cabinitem->GetString("saleprice"));
                AddXMLListAttribute(vcabinNode, "classcode", cabinitem->GetString("classcode"));
                AddXMLListAttribute(vcabinNode, "buildfee", cabinitem->GetString("buildfee"));
                AddXMLListAttribute(vcabinNode, "fuelfee", cabinitem->GetString("fuelfee"));
                AddXMLListAttribute(vcabinNode, "isApply", cabinitem->GetString("isApply"));
                AddXMLListAttribute(vcabinNode, "tgqInfo", cabinitem->GetString("tgqInfo"));
                AddXMLListAttribute(vcabinNode, "aheadDays", cabinitem->GetString("aheadDays"));
                vNode.appendChild(vcabinNode);
                delete cabinitem;
            }
        delete item;
        }
    }
    delete vJson;
    return GetReturnXML();
}

QString PlaneTicket::ParseOrderAirPlanReturn(QString returnStr)
{
    Json* vJson;
    Json* item;
    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command", "12");
    AddXMLParam("operate", "14");
    if(returnStr.isEmpty())
    {
        AddXMLParam("success", "1");
        SetPrintInfoSystemCode("00000000");
        return GetReturnXML();
    }
    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")!="JSON_NONE")
    {
        AddXMLParam("success", "1");
        SetPrintInfoSystemCode("00000001");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success", "0");
        AddXMLParam("errormsg", vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success", "1");

    }
    delete vJson;
    return GetReturnXML();
}

QString PlaneTicket::ParseNotifyPlayInfoReturn(QString returnStr)
{
    Json* vJson;
    vJson = new Json(returnStr);
    vJson->Delete("CTSRespBody");
    convertor->JsonToXmlFullWithCommand(vJson->toString(),"","");
    delete vJson;
    return "";
}

QString PlaneTicket::QueryAirNumberWithPrice(QString org, QString dst, QString airways, QString fltd)
{
    Json vjson;
    QStringList temp;
    ClearBodys();
      this->json->SetValue("CTSReqHeader.TranCode","015001");
      this->json->SetValue("CTSReqHeader.CMD","AV");
      this->json->SetValue("CTSReqBody.org",org);
      this->json->SetValue("CTSReqBody.dst",dst);
      this->json->SetValue("CTSReqBody.airways",airways);
      this->json->SetValue("CTSReqBody.fltd",fltd);
    return ParseQueryAirNumberReturn(RequestInterface(GetReqString()));
}

void PlaneTicket::InitPrintInfo()
{
}

void PlaneTicket::SetBasePrintInfo(QString busstype, QString trancode, QString tranmoney, QString trantime)
{
}

void PlaneTicket::SetPrintInfoSystemCode(QString systemcode)
{
}



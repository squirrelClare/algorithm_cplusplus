#ifndef COMANYLIST_H
#define COMANYLIST_H
#include <QString>
#include "json.h"
#include "machineinfo.h"
#include "database.h"
#include "debugger.h"
#include "tradebase.h"
#include <QSqlDatabase>
#include <QSqlRecord>
#include <QSqlField>
#include <QtXml>
class ComanyList : public TradeBase
{
public:
    ComanyList(QMap<QString, CommandHandler> *map,Database *db,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) ;

    QString QueryNotice(Json *json);
    QString QueryCompanyList(Json* json);
    QString QueryIntro(Json* json);

private:
    MachineInfo *machineInfo;
    Database *db;

};

#endif // COMANYLIST_H

﻿#include "moviecommonticket.h"

MovieCommonTicket::MovieCommonTicket(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{
    map->insert("5005,1002",
    {
                    this,
                    (CmdProcFun)&MovieCommonTicket::ExecuteCharge,
                    "电影通票"
                });
}

QString MovieCommonTicket::ExecuteCharge(Json *json)
{
    return OrderSubmit(json);
}


QString MovieCommonTicket::OrderSubmit(Json *json)
{
    ClearBodys();
    SetHeadContacter(json->GetString("header.phone"));
    this->json->SetValue("CTSReqHeader.TranCode","018013");
    this->json->SetValue("CTSReqBody.cinemaId",json->GetString("header.cinemaId"));
    this->json->SetValue("CTSReqBody.tid",json->GetString("header.tid"));
    this->json->SetValue("CTSReqBody.count",json->GetString("header.count"));
    this->json->SetValue("CTSReqBody.price",QString::number(json->GetString("header.money").toInt()*100));
    this->json->SetValue("CTSReqBody.userPhone",json->GetString("header.userPhone"));
    this->json->SetValue("CTSReqBody.tEnableDay",json->GetString("header.tEnableDay"));
    this->json->SetValue("CTSReqBody.cinemaName",json->GetString("header.cinemaName"));

    strSuccessMsg="您已经成功购买电影票通票，谢谢！";
    return ParseOrderSubmit(RequestInterface(GetReqString()));
}


QString MovieCommonTicket::ParseOrderSubmit(QString returnStr)
{
    Json *vJson;
    srvsuccess=true;
    ReInitXMLDoc();
    AddXMLParam("command","5005");
    AddXMLParam("operate","1002");

    if(returnStr=="")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        AddXMLParam("success","1");
        return GetReturnXML();
    }

    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        AddXMLParam("success","0");
        AddXMLParam("errormsg",vJson->GetString("CTSRespHeader.Comment"));
        srvsuccess=false;
    }
    else
    {
        AddXMLParam("success","1");
    }
    delete vJson;
    return GetReturnXML();
}


QString MovieCommonTicket::GetChargeTxCode(Json *json)
{
    return "018013";
}


QString MovieCommonTicket::GetChargeMoney(Json *json)
{
    return json->GetString("header.money");
}

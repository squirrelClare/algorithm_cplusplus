﻿#include "electricitybill.h"

ElectricityBill::ElectricityBill(QMap<QString, CommandHandler> *map,MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger) : TradeBase(machineInfo,config,debugger)
{

}

QString ElectricityBill::ExecuteCharge(Json *json)
{
    return Charge(json);
}

QString ElectricityBill::GetChargeMoney(Json *json)
{
    return QString::number( json->GetString("header.totalamt").toInt() / 100);
}

QString ElectricityBill::GetChargeTxCode(Json *json)
{
    return "007002";
}


QString ElectricityBill::TestCharge()
{
}

QString ElectricityBill::ChargeConfirm(Json *json1, Json *json2)
{
    ClearBodys();
    SetHeadContacter(json1->GetString("header.mobile"));
    this->json->SetValue("CTSReqHeader.TranCode","007003");
    this->json->SetValue("CTSReqBody.password","21218cca77804d2ba1922c33e0151105");
    this->json->SetValue("CTSReqBody.ContactNo","");
    this->json->SetValue("CTSReqBody.TerminalNo","");
    this->json->SetValue("CTSReqBody.UserName","");
    this->json->SetValue("CTSReqBody.TermID","");
    this->json->SetValue("CTSReqBody.ReqCode","4703");
    this->json->SetValue("CTSReqBody.ReqData.AccDate","");
    this->json->SetValue("CTSReqBody.ReqData.PayMonths","");
    this->json->SetValue("CTSReqBody.ReqData.TotalAmt","");
    this->json->SetValue("CTSReqBody.ReqData.OrderNo","");
    this->json->SetValue("CTSReqBody.ReqData.SerialNumber","");
    this->json->SetValue("CTSReqBody.ReqData.ThirdPart","");
    this->json->SetValue("CTSReqBody.ReqData.PayType","");
    this->json->SetValue("CTSReqBody.ReqData.ReqData.ThirdFlow","");

    return RequestInterface(GetReqString());
}

QString ElectricityBill::ChargeRequest(Json *json)
{
    ClearBodys();
    this->json->SetValue("CTSReqHeader.TranCode", "007002");
    this->json->SetValue("CTSReqBody.password","21218cca77804d2ba1922c33e0151105");//u_GlobalVar.pGlobalConfig.Get_Union_TerminalPassword;//'21218cca77804d2ba1922c33e0151105';//
    this->json->SetValue("CTSReqBody.ContactNo", "u_GlobalConst.p_StoreNo");//'PC711';//
    this->json->SetValue("CTSReqBody.TerminalNo", "u_GlobalVar.pGlobalConfig.Get_Union_TerminalID");
    this->json->SetValue("CTSReqBody.ReqCode", "4701");
    this->json->SetValue("CTSReqBody.ReqData.Operator", "PC711");
    this->json->SetValue("CTSReqBody.ReqData.ClientID", json->GetString("header.clientid"));
    this->json->SetValue("CTSReqBody.ReqData.PayMonth", json->GetString("header.paymonth"));
    this->json->SetValue("CTSReqBody.ReqData.PayMonths", json->GetString("header.paymonths"));
    this->json->SetValue("CTSReqBody.ReqData.TotalAmt", json->GetString("header.totalamt"));
    this->json->SetValue("CTSReqBody.ReqData.ClientName",json->GetString("header.username"));
    strSuccessMsg = "您已成功缴纳电费：" + GetChargeMoney(json) + "元";

    return RequestInterface(GetReqString());

}

QString ElectricityBill::Charge(Json *json)
{
    QString RequestReturn;
    Json *vJson;
    srvsuccess=false;
    RequestReturn = ChargeRequest(json);
    if(RequestReturn=="")
    {
        RequestReturn = ChargeRequest(json);
    }
    if(RequestReturn!="")
    {
        vJson = new Json(RequestReturn);
        RequestReturn = ChargeConfirm(json,vJson);
        delete vJson;
    }

    return ParseCharge(RequestReturn);
}

QString ElectricityBill::ParseCharge(QString returnStr)
{
    Json *vJson;
    srvsuccess=true;
    if(returnStr=="")
    {
        return "";
    }
    vJson = new Json(returnStr);
    if(vJson->GetType("CTSRespHeader.ResultCode")=="JSON_NONE")
    {
        return "";
    }
    if(vJson->GetString("CTSRespHeader.ResultCode")!="CTS0000")
    {
        srvsuccess=false;
    }
    delete vJson;
    return "";


}



QString ElectricityBill::ParseChargeConfirm(QString returnStr)
{
    return "";
}

QString ElectricityBill::ParseChargeRequest(QString returnStr)
{
    return "";
}

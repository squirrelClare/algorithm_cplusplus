#ifndef UNIONPAY_H
#define UNIONPAY_H
#include <QString>
#include "messageflex.h"
#include "database.h"
#include "debugger.h"
class MessageFlex;
class UnionPay
{
private:
    QString bankEncryptPIN;

    QString consumeMoney;   //银联刷卡金额
    QString productMoney;   //购买产品金额
    QString reversalMoney;  //冲正金额

    bool isSignIned;
    MessageFlex *messageFlex;
    Database *db;
    Debugger *debug;
public:
    UnionPay(MessageFlex *messageFlex, Database *db, Debugger *debug);
    bool SignIn();       //签到

    bool GetPIN();
    bool InputPassword();
    QString SwipeCard();

    int Consume(int money);

};

#endif // UNIONPAY_H

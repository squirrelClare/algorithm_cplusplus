#ifndef CONSUMEUPLOADER_H
#define CONSUMEUPLOADER_H
#include <QString>
#include <QtNetwork>
#include "common.h"
#include "debugger.h"
#include "json.h"
class ConsumeUploader
{
private:
    QString serverAddress;
    Debugger *debug;
    QString PostDataToServer(QString serverURL,QString data);
public:
    ConsumeUploader(QString serverAddress,Debugger *debug);
    bool UploadConsumeInfo(QString termID,int OperType,QString operResult,QString watchNo,QString batchNo,QString bankCardNo,QString consumeTime,QString consumeFee,QString txCode);

};

#endif // CONSUMEUPLOADER_H

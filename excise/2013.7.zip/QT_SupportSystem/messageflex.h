#ifndef MESSAGEFLEX_H
#define MESSAGEFLEX_H
#include <QWidget>
#include <QtNetwork>
#include <QDebug>
#include <QFile>
#include <QFileInfo>
#include <QSettings>
#include <QTime>
#include <QTextCodec>
#include <QtXml>

#include "debugger.h"
#include "json.h"

#include "converter.h"
#include "common.h"
#include "globalconfig.h"
#include "database.h"
#include "machineinfo.h"
#include "unionpay.h"
#include "consumeuploader.h"
#include "downloader.h"

#include "tradebase.h"
#include "comanylist.h"
#include "mobilerecharge.h"
#include "gamerecharge.h"
#include "onlinemall.h"
#include "picturedownloader.h"
#include "weather.h"
#include "planeticket.h"
#include "coupon.h"
#include "traffictax.h"
#include "creditrecharge.h"
#include "movieticket.h"
#include "moviecommonticket.h"

enum ENUM_Page
{
    P_MAIN=0,
    P_PublicInfo,
    P_PubError,
    P_SkyMain,
    P_CardPassMain,
    P_DisPassWord,
    P_CommonInfo,
    P_WeiHu,
    P_VipReg,
    P_Weather,
    P_Query,
    P_TelephoneStr,
    P_WaitCard,
    P_TmpForm,
    P_NoPaper,
    P_DetailMoney,
    P_WaitCardCredit,
    P_DisPassWordCredit,
    P_WaitCardForm,
    P_PWForm,
    P_PowerError,
    P_Reprint,
    P_CaiPiaoMain
};
class MessageFlex;
class UnionPay;

class MessageFlex : public QObject
{
    Q_OBJECT
public:
    void GotoPage(ENUM_Page page,QString msg="");


    MessageFlex();
    ~MessageFlex();
private:
    QString curDir;
    QString curModule;
    QTcpServer *server;
    QTcpServer *secureServer;

    QTcpSocket *client;
    QTcpSocket *secureClient;



    QMap<QString,CommandHandler> map;

    GlobalConfig *config;
    UnionPay *unionPay;
    ConsumeUploader *uploader;
    TradeBase *curTradeBase;


    bool g_IsBusy;
    Debugger *g_debuger;
    MachineInfo *machineInfo;
    Database *db;

    MobileRecharge *appMobileRecharge;
    GameRecharge *appGameRecharge;
    ComanyList *appCompanyList;
    OnlineMall *appOnlineMall;
    PictureDownloader *appPictureDownloader;
    Weather *appWeather;
    PlaneTicket *appPlaneTicket;
    Coupon  *appCoupon;
    TrafficTax *appTrafficTax;
    CreditRecharge *appCreditRecharge;
    MovieTicket *appMovieTicket;
    MovieCommonTicket *appMovieCommonTicket;

    void AddRandomToUnipaySer();

    void BeforeUnionPayConsume();
    void DoAfterSignIn(bool isSuccess);
    void DoAfterService(bool isSuccess,TradeBase *tradebase);

    QString CommonCharge(Json *json,TradeBase *tradebase);
    bool UploadInfo(Json *json,int operResult,TradeBase *tradebase,QString watchNo,QString batchNo,QString consumeFee,QString consumeTime,QString cardNo);

    QString GetPageString(ENUM_Page page,QString msg);

    void HandleClient(QString command);
    bool SendXMLToFlex(QString xml);

    void WriteDebug(QString string);
signals:
    void OnNewLogInfo(QString info);
public slots:

    void On_Server_NewConnIn();//新的连接请求
    void On_SecureServer_NewConnIn();

    void On_Client_DataIn();
    void On_SecureClient_DataIn();
};

#endif // MESSAGEFLEX_H

#ifndef MACHINEINFO_H
#define MACHINEINFO_H
#include<QString>
#include<QSettings>
#include "database.h"
class  MachineInfo
{
public:
    MachineInfo(Database *db);
    QString MachineId;
    int AreaId;
    QString AreaName;
    int MansionId;
    QString MansionName;
    QString MachineGroupId;
    QString MachineCategoryId;
    QString CategoryName;
    int FloorId;
    QString MachineArea;

};

#endif // MACHINEINFO_H

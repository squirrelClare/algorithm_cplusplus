#include "unionpay.h"

UnionPay::UnionPay(MessageFlex *messageFlex, Database *db, Debugger *debug)
{
    this->messageFlex = messageFlex;
    this->db = db;
    this->debug = debug;

}

bool UnionPay::SignIn()
{
    int i;
    for(i=0;i<3;i++)
    {
        //执行签到动作
        isSignIned=true;
    }
    if(isSignIned)
    {
        //签到成功
    }
    else
    {
        //签到失败
    }
    return isSignIned;
}


QString UnionPay::SwipeCard()
{
    QString bankCardNo;
    QString cardNo="";
    bool result=false;
    int iRetry=0;
    for(iRetry=0; iRetry < 3 ; iRetry++)
    {
        Common::WriteDebug("开始获取卡号：");
        this->messageFlex->GotoPage(P_WaitCard,"");

        //从FLEX获得卡号
        //bankCardNo = ";6222803112061002537=40035200021020000?";
        bankCardNo="";

        if(bankCardNo=="timeout" || bankCardNo=="")
        {
            messageFlex->GotoPage(P_CommonInfo,"刷卡超时");
            Common::Sleep(2000);
            return "";
        }

        //截取卡号中的二轨数据
        result=true;
        int iStart,iEnd;
        if(bankCardNo.length()<15) result=false;
        iStart = bankCardNo.indexOf(";");
        iEnd = bankCardNo.indexOf("?");
        if(iStart<0) result=false;
        if(iEnd<0 || iEnd <= iStart) result=false;

        if(result)
        {
            cardNo = bankCardNo.mid(iStart+1,iEnd-iStart-1);
            Common::WriteDebug("获取卡号成功：" + cardNo);
            return cardNo;
        }
        if(iRetry<=1)
        {
            messageFlex->GotoPage(P_CommonInfo,"刷卡产生异常！请更换卡片或者调整刷卡姿态重新刷卡...");
            Common::Sleep(3000);
        }
        else
        {
            messageFlex->GotoPage(P_CommonInfo,"刷卡产生异常！不能正确获得卡信息！");
            Common::Sleep(2000);
        }

    }
    return cardNo;
}

int UnionPay::Consume(int money)
{
    QString cardNo;
    int consumeResult;

    cardNo = SwipeCard(); //获取卡号

    if(cardNo == "") return -1; //卡号为空

   //终端尚未签到
    if(isSignIned==false)
    {

        messageFlex->GotoPage(P_CommonInfo,"正在连接支付接口，请稍后...");
        Common::Sleep(1000);
        if(SignIn()==false)
        {
            messageFlex->GotoPage(P_CommonInfo,"连接支付接口失败...");
            Common::Sleep(2000);
            return -5;  //签到失败
        }
    }

    //输入密码
    if(InputPassword()==false)return -1;

    //执行消费动作
    consumeResult = 0;

    switch(consumeResult)
    {
    case 0:
        break;
    case 94:
        //终端尚未签到
         if(isSignIned==false)
         {
             messageFlex->GotoPage(P_CommonInfo,"正在连接支付接口，请稍后...");
             Common::Sleep(1000);
             if(SignIn()==false)
             {
                 messageFlex->GotoPage(P_CommonInfo,"连接支付接口失败...");
                 Common::Sleep(2000);
                 return -5;  //签到失败
             }
         }
         break;
    case 55:
        //密码错误
        break;

    }

    return consumeResult;


}


bool UnionPay::InputPassword()
{
    Common::WriteDebug("请输入密码：");
    messageFlex->GotoPage(P_DisPassWord);
    Common::Sleep(3000);

    Common::WriteDebug("输入密码完成 ！");
    return true;
}

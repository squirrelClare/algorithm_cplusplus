#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "serializer.h"
#include<QVariant>
#include<QStringList>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    flex = new MessageFlex();
    connect(flex,SIGNAL(OnNewLogInfo(QString)),this,SLOT(AddMemo(QString)));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::AddMemo(QString msg)
{
    ui->listWidget->insertItem(0,msg.left(100));
}

#ifndef DATABASE_H
#define DATABASE_H
#include<QString>
#include<QSqlDatabase>
#include<QSqlQuery>
#include <QSettings>
#include<QDebug>
class Database
{
public:
    Database();
    ~Database();

    bool InitDatabase();
    bool InitDatabase2();
    bool ExecuteSQL(QString sqlstr);
    bool ExecuteSQL2(QString sqlstr);
    bool QuerySQL(QString sqlstr,QSqlQuery* result);
    QString GetString(QString sqlstr);
    int GetInteger(QString sqlstr);
    bool IsValid();
private:
    QSqlDatabase db;
    bool isvalid;


};

#endif // DATABASE_H

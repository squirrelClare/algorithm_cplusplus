#ifndef DOWNLOADER_H
#define DOWNLOADER_H
#include <QDebug>
#include <QThread>
#include <QString>
#include <QList>
#include <QStringList>
#include <QtNetwork>
#include "common.h"
class Downloader : public QThread
{
    Q_OBJECT
public:
    explicit Downloader(QStringList list,QObject *parent = 0);
    void run();
private:
    QStringList fileList;
    QStringList urlList;
    QNetworkAccessManager* nam;
signals:
    void downloadFinished();
public slots:
    
};

#endif // DOWNLOADER_H

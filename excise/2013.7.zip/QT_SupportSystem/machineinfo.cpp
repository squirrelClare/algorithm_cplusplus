#include "machineinfo.h"

MachineInfo::MachineInfo(Database *db)
{
    QSettings *setting=new QSettings("Private.ini",QSettings::IniFormat);
    MachineId=setting->value("Info/TerminalID","10000001").toString();
    AreaId=db->GetInteger("Select area_id from et_terminal where id = " + MachineId);
    AreaName=db->GetString("Select title from et_area where id = " + QString::number(AreaId));
    MansionId=db->GetInteger("Select mansion_id from et_terminal where id = " + MachineId);
    MachineGroupId=db->GetString("Select group_id from et_terminal where id = " + MachineId);
    if(MachineGroupId=="")
    {
        MachineGroupId="0";
    }

    MachineCategoryId=db->GetString("Select category_id from et_terminal_group where id = " + MachineGroupId);
    if(MachineCategoryId=="")MachineCategoryId="0";

    CategoryName=db->GetString("Select title from et_category where id = " + MachineCategoryId);

    MachineArea = setting->value("Info/Area","10000255").toString();
    FloorId= setting->value("Info/FloorId","9999").toInt();

}

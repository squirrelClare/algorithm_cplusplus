#include "consumeuploader.h"

QString ConsumeUploader::PostDataToServer(QString serverURL, QString data)
{
    Common::WriteDebug("向CTS服务器发送数据：" + data);
    QUrl url = serverURL;
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader,"application/x-www-form-urlencoded");
    request.setHeader(QNetworkRequest::ContentLengthHeader,data.length());

    QNetworkAccessManager *nam = new QNetworkAccessManager();
    QNetworkReply *ret = nam->post(request,data.toAscii());
    QByteArray byteString;
    QString string;
    QEventLoop eventLoop;

    QObject::connect(nam, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));
    eventLoop.exec();       //block until finish

    if(ret->error()==QNetworkReply::NoError)
    {
        byteString = ret->readAll();
        QTextCodec *codec=QTextCodec::codecForName("GBK");
        string = codec->toUnicode(byteString);
        Common::WriteDebug("CTS服务器返回数据："+string);
    }
    else
    {
        Common::WriteDebug("CTS服务器返回数据错误！");
        string="";
    }

    ret->deleteLater();;
    return string;
}

ConsumeUploader::ConsumeUploader(QString serverAddress,Debugger *debug)
{
    this->serverAddress = serverAddress;
    this->debug = debug;
}
/*
 *OperType 操作类型 1 扣款 2 冲正
  OperResult 操作结果 0 失败  1 成功
  watchno 流水号
  batchno 批次号
  bankcardno 银行卡号
  consumetime 消费时间
  consumefee 消费金额（分为单位）
  使用说明: 在扣款后，冲正后这两个时间点调用这个函数记录这两个操作的结果到服务器
  */
bool ConsumeUploader::UploadConsumeInfo(QString termID, int OperType, QString operResult, QString watchNo, QString batchNo, QString bankCardNo, QString consumeTime, QString consumeFee, QString txCode)
{
    bool result=false;
    QString respone;
    Json *json = new Json();
    Json *retJson;
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString dateTimeStr = time.toString("yyyy-MM-dd hh:mm:ss"); //设置显示格式
    json->SetValue("AgentReqHeader.SysDate",dateTimeStr);
    json->SetValue("AgentReqHeader.TerminalID",termID);
    json->SetValue("AgentReqHeader.txcode",txCode);
    json->SetValue("AgentReqHeader.EventType","0000001");
    json->SetValue("AgentReqBody.AgentReqBody7.OperType",QString::number(OperType));
    json->SetValue("AgentReqBody.AgentReqBody7.OperResult",operResult);
    json->SetValue("AgentReqBody.AgentReqBody7.watchno",watchNo);
    json->SetValue("AgentReqBody.AgentReqBody7.batchno",batchNo);
    json->SetValue("AgentReqBody.AgentReqBody7.bankcardno",bankCardNo);
    json->SetValue("AgentReqBody.AgentReqBody7.consumetime",consumeTime);
    json->SetValue("AgentReqBody.AgentReqBody7.consumefee",consumeFee);

    respone = PostDataToServer(this->serverAddress,json->toString());
    if(respone!="")
    {
        retJson = new Json(respone);
        if(retJson->GetString("AgentRespHeader.Status")=="0")
        {
            result=true;
        }
    }
    return result;
}

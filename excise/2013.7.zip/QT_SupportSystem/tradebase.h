#ifndef CTRADEBASE_H
#define CTRADEBASE_H
#include "json.h"
#include "debugger.h"
#include <QString>
#include <QStringList>
#include <QHash>
#include <QtXml>
#include <QtNetwork>
#include <QDateTime>
#include <QObject>
#include <QDebug>
#include <QTime>
#include "common.h"
#include "machineinfo.h"
#include "globalconfig.h"
class TradeBase;

typedef QString (TradeBase::*CmdProcFun)(Json *);

typedef struct
{
    TradeBase* app;
    CmdProcFun func;
    QString    desc;
} CommandHandler;

class TradeBase : public QObject
{
    Q_OBJECT
public:
    TradeBase(MachineInfo* machineInfo,GlobalConfig *config, Debugger *debugger);

    virtual ~TradeBase();

    bool srvsuccess;
    bool credit;
    int creditflag;
    QString cachestring;
    QString flag;
    QString operate;

    QString GetReqString();
    void SetTradeTerminalNo(QString termno);
    void SetHeadUserID(QString value);
    void SetHeadTxAccount(QString value);
    void SetHeadTxAmt(QString value);
    void SetHeadContacter(QString value);
    void SetHeadMsgRefID(QString value);
    void SetHeadOrigSender(QString value);

    virtual bool PreCharge(Json* json);
    virtual bool PostCharge(Json* json);
    virtual QString GetChargeMoney(Json *json);
    virtual QString ExecuteCharge(Json *json);
    virtual QString GetChargeTxCode(Json *json);
    virtual QStringList GetPrintInfos();
    QString GetSuccessMsg();
    QString GetErrorMsg();
    QString EncryptCardNo(QString card);

    void DoTest();
private:

    QDomDocument xmlDoc;
    QStringList ResultStrList;
    Debugger *debug;

    void InitHeader();
    void CreateXMLBase();
protected:
    MachineInfo *machineInfo;
    GlobalConfig *config;

    Json *json;
    QString strTradeTerminalNo;
    QString strTradePassword;
    QString strSuccessMsg;
    QString strErrorMsg;
    QString strTxCode;
    QHash<QString,QString> PrintInfo;

    void ClearBodys();
    void SetResultCode();
    void AddXMLParam(QString strName,QString strValue);
    QDomElement AddXMLList();
    void AddXMLListAttribute(QDomElement node,QString nodeName,QString value);
    void AddXmlListNode(QDomElement node);
    QString GetReturnXML();
    void ReInitXMLDoc();
    QString RequestInterface(QString json_packet);
    QString URLencode(QString str);
    QDomElement getParamsNode();
    void WriteDebugMessage(QString msg);

    QString GetOrigSender();
    QString GetQueryMesgRefID();
    QString GetOrderMesgRefID();
    void SetTxHeader(QString UserId, QString TxAccount, QString TxAmt, QString Contacter, QString MesgRefID, QString OrigSender);


};

#endif // CTRADEBASE_H

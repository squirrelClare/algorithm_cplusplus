#include "json.h"
#include<QDebug>
Json::Json()
{

}

Json::Json(QString json)
{
    QJson::Parser parser;

    json_obj = parser.parse(json.toAscii(),&isValid);

}


QString Json::operator [](QString key)
{

    return GetString(key);
}


QString Json::toString()
{
    QJson::Serializer s;
    json_string=s.serialize(json_obj);
    return json_string;

}

QVariant Json::toVariant()
{
    return json_obj;
}

QVariant Json::SetValue(QString key, QString value, QVariant json)
{

    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;
    QVariant result;
    if(json.canConvert<QVariantList>())
    {
        QVariantList list = json.toList();
        map= list[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);
        json_child = map[key_first];
        result=SetValue(key_left,value,json_child);
        map[key_first]=result;
        result=map;
    }
    else
    {
        map[key]=value;
        result=map;
    }
    return result;
}

QVariant Json::AddJson(QString key, QVariant value, QVariant json)
{
    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;

    QVariantList list;
    QVariant result;

    if(json.canConvert<QVariantList>())
    {
        QVariantList list2 = json.toList();
        map= list2[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);
        json_child = map[key_first];
        result=AddJson(key_left,value,json_child);
        map[key_first]=result;
        result=map;
    }
    else
    {
        result = map[key];
        if(result.canConvert<QVariantList>())
        {
            list = result.toList();
            list << value;
        }
        else
        {
            if(!result.isNull())list << result;
            list << value;
        }
        map[key]=list;
        result = map;

    }
    return result;
}

QVariant Json::AddList(QString key, QStringList value, QVariant json)
{
    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;

    QVariantList list;
    QVariant result;

    if(json.canConvert<QVariantList>())
    {
        QVariantList list2 = json.toList();
        map= list2[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);
        json_child = map[key_first];
        result=AddList(key_left,value,json_child);
        map[key_first]=result;
        result=map;
    }
    else
    {

        QVariantList lst;
        for(int i=0;i<value.count();i++)
        {
            lst << value.at(i);
        }
        map[key]=lst;
        result = map;
    }
    return result;
}

QVariant Json::Delete(QString key, QVariant json)
{
    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;
    QVariant result;
    if(json.canConvert<QVariantList>())
    {
        QVariantList list = json.toList();
        map= list[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);
        json_child = map[key_first];
        result=Delete(key_left,json_child);
        map[key_first]=result;
        result=map;

    }
    else
    {
        map.remove(key);
        result=map;

    }
    return result;
}

QVariant Json::GetVariant(QString key, QVariant json)
{
    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;
    QVariant result;
    if(json.canConvert<QVariantList>())
    {
        QVariantList list = json.toList();
        map= list[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);
        json_child = map[key_first];
        result=GetVariant(key_left,json_child);
    }
    else
    {
        result=map[key];
    }
    return result;

}



QString Json::GetString(QString key)
{

    QString result = GetString(key,json_obj);
    return result;
}

QString Json::GetString(QString key, int index)
{
    QVariant json;
    QVariantMap map;
    if(key=="")
    {
        json=json_obj;
    }
    else
    {
        json=GetVariant(key,json_obj);
    }

    if(GetType(key)=="JSON_OBJECT")
    {
        map=json.toMap();
        return map.values().at(index).toString();
    }

    return "";
}

QString Json::GetString(QString key, QVariant json)
{

    QVariantMap map;
    QVariant json_child;
    QString  key_first;
    QString  key_left;
    QString result;
    if(json.canConvert<QVariantList>())
    {
        QVariantList list = json.toList();
        map= list[0].toMap();
    }
    else
    {
        map=json.toMap();
    }

    if(key.contains("."))
    {
        key_first = key.left(key.indexOf("."));
        key_left = key.right(key.length()-key.indexOf(".")-1);

        json_child = map[key_first];
        return GetString(key_left,json_child);
    }
    else
    {
        QVariant v = map[key];
        if(v.canConvert<QVariantList>() || v.canConvert<QVariantMap>())
        {
            QJson::Serializer s;
            result = s.serialize(v);
        }
        else
        {
            result = map[key].toString();
        }

        return result;
    }
}

QString Json::GetType(QString key)
{
    QString jsonstr=GetString(key);

    if(jsonstr.startsWith("["))
    {
        return "JSON_LIST";
    }
    if(jsonstr.startsWith("{"))
    {
        return "JSON_OBJECT";
    }
    if(jsonstr=="")
    {
        return "JSON_NONE";
    }
    return "JSON_END_NODE";

}

int Json::GetCount(QString key)
{
    QString type=GetType(key);
    QVariant json=GetVariant(key,json_obj);

    if(type=="JSON_LIST")
    {
        QVariantList list=json.toList();
        return list.count();
    }
    if(type=="JSON_OBJECT")
    {
        QVariantMap map=json.toMap();
        return map.count();
    }
    if(type=="JSON_NONE")
    {
        return 0;
    }
    return 1;

}

QString Json::GetName(QString key,int index)
{
    QString type=GetType(key);
    QVariantMap map;
    QVariant json;
    if(key=="")
    {
        json=json_obj;
    }
    else
    {
        json=GetVariant(key,json_obj);
    }


    if(type=="JSON_LIST")
    {
        QVariantList list=json.toList();
        map=list.at(0).toMap();
        if(index < map.keys().count())
        {
            return map.keys().at(index);
        }
    }
    if(type=="JSON_OBJECT")
    {
        map=json.toMap();
        if(index < map.keys().count())
        {
            return map.keys().at(index);
        }
    }
    if(type=="JSON_NONE")
    {
        return "";
    }
    return "";
}

bool Json::Delete(QString key)
{
    json_obj = Delete(key,json_obj);
    return true;
}

bool Json::IsValid()
{
    return isValid;
}


bool Json::SetValue(QString key, QString value)
{
    json_obj = SetValue(key,value,json_obj);

    return true;
}

bool Json::AddJson(QString key, Json json)
{
    json_obj = AddJson(key,json.toVariant(),json_obj);
    return true;

}

bool Json::AddList(QString key, QStringList list)
{


    json_obj = AddList(key,list,json_obj);
    return true;

}


bool Json::AddValue(QString key, QString value)
{

}


QString Json::GetJson(QString key, int index)
{
    QVariant json;
    QVariantList list;
    QString result="";
    if(GetType(key)=="JSON_LIST")
    {
        json = GetVariant(key,json_obj);
        if(json.canConvert<QVariantList>())
        {
            list = json.toList();
            if(index<list.count())
            {
            QJson::Serializer s;
            result = s.serialize(list.at(index));
            }
        }
    }
    return result;
}

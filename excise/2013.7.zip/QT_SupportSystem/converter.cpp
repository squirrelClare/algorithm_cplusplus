#include "converter.h"

Converter::Converter()
{
}


QString Converter::JsonToXmlFullWithCommand(QString jsonStr, QString command, QString oper)
{
    Json *json;

    QDomDocument xml;
    QDomProcessingInstruction ins;
    QDomElement node;
    QDomElement rootNode;
    QDomElement newNode;

    QString success;
    QString errormsg;
    QString ResultCode;

    json=new Json(jsonStr);
    if(json->IsValid())
    {
        ins=xml.createProcessingInstruction("xml","version=\"1.0\" encoding=\"UTF-8\"");
        xml.appendChild(ins);

        rootNode=xml.createElement("root");
        node = xml.createElement("params");

        ResultCode = json->GetString("CTSRespHeader.ResultCode");
        if(ResultCode=="CTS0000")
        {
            success="1";
            errormsg="";
        }
        else
        {
            success="0";
            errormsg=json->GetString("CTSRespHeader.Comment");
        }
        node.setAttribute("command",command);
        node.setAttribute("oper",oper);
        node.setAttribute("success",success);
        node.setAttribute("errormsg",errormsg);


        if(json->GetType("CTSRespBody") == "JSON_OBJECT")
        {
            for(int i=0;i<json->GetCount("CTSRespBody");i++)
            {

                newNode = xml.createElement(json->GetName("CTSRespBody",i));
                newNode.appendChild(xml.createTextNode(json->GetString("CTSRespBody",i)));

                node.appendChild(newNode);
            }
        }

        rootNode.appendChild(node);
        xml.appendChild(rootNode);
        return xml.toString();
    }
    return "";
}


QString Converter::XmlFullToJson(QString xmlStr)
{
    QDomDocument xml;
    QDomNode rootNode,node;
    QDomNodeList nodeList;
    QString nodeName,nodeValue;
    Json *json;
    Json *json_item;

    int i,j;
    if(xml.setContent(xmlStr))
    {
        json=new Json();
        rootNode = xml.firstChild();

        for(j=0;j<rootNode.childNodes().count();j++)
        {
            node = rootNode.childNodes().item(j);
            if(node.nodeName()=="params")
            {
                for(i=0;i<node.attributes().count();i++)
                {
                    nodeName = node.attributes().item(i).nodeName();
                    nodeValue = node.attributes().item(i).nodeValue();
                    json->SetValue("header."+nodeName,nodeValue);
                }
                break;
            }
        }

        nodeList = node.childNodes();
        if(nodeList.isEmpty()==false)
        {
            for(j=0;j<nodeList.count();j++)
            {
                json_item = new Json();
                for(i=0;i<nodeList.item(j).attributes().count();i++)
                {
                    nodeName = nodeList.item(j).attributes().item(i).nodeName();
                    nodeValue = nodeList.item(j).attributes().item(i).nodeValue();
                    if(nodeValue.isNull())
                    {
                        nodeValue="";
                    }
                    json_item->SetValue(nodeName,nodeValue);
                }
                json->AddJson("body.lists",*json_item);
            }
        }
        return json->toString();
    }
    else
    {
        return "";
    }
}


void Converter::JsonOperOneNode(Json json, QDomNode node)
{

}

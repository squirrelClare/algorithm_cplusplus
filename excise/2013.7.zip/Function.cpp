﻿QString Query011011(Json *json)
{
	QSqlQuery uniQ;
	QString keyword,order,page,pagesize,center,x,y,scope,cityaddrlist;
	QString sql,sqlcount,start;
	int amount,pages,maxShop;
	Json *vJson,*url,*urls;
	bool boo;
	int i,j;
	QString expdate;
	uniQ=new QSqlQuery(null);
	DataBase.QuerySQL(getPingpai,uniQ);
	vJson=new JSon();
	vJson->SetValue("CTSRespHeader.TranCode","011011");
    vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
    vJson->SetValue("CTSRespHeader.Channel","");
    vJson->SetValue("CTSRespHeader.MesgRefID","");
    vJson->SetValue("CTSRespHeader.OrigSender","");
    vJson->SetValue("CTSRespHeader.Userid","");
    vJson->SetValue("CTSRespHeader.Comment","");
    vJson->SetValue("CTSRespHeader.TxAccount","");
    vJson->SetValue("CTSRespHeader.TxAmt","");
    vJson->SetValue("CTSRespHeader.Contacter","");
//urls := SA([]);
	QSqlRecord rs;
    rs=uniQ.record();
	while(uniQ.next())
	{
		url=new Json();
		url->SetValue("cb_id",rs.field("categorySub").value().toString();
      url->SetValue("cb_name",rs.field("category").value().toString());
      url->SetValue("cb_img",rs.field("imgsrc220").value().toString());
      url->SetValue("cityno",rs.field("city").value().toString());
	 // urls.AsArray.Add(url);
      uniQ.next();
	}
	vJson->SetValue("CTSRespBody.result",urls);

	AddXMLParam("command", "9000");
    AddXMLParam("operate", "011011");
    AddXMLParam("json", vJson->toString());
	return GetReturnXML();
	insertddclick("","011011",datetimetostr(now),"");
}

QString Query011013(Json *json)
{	
	QSqlQuery uniQ;
	QString id,sql;
	int i;
	Json *vJson,*vJsonItem,*shops;
	id=json->GetString("header.id");
	vJson=new Json();
	vJson->SetValue("CTSRespHeader.TranCode","011013");
  vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
  vJson->SetValue("CTSRespHeader.Channel","");
  vJson->SetValue("CTSRespHeader.MesgRefID","");
  vJson->SetValue("CTSRespHeader.OrigSender","");
  vJson->SetValue("CTSRespHeader.Userid","");
  vJson->SetValue("CTSRespHeader.Comment","");
  vJson->SetValue("CTSRespHeader.TxAccount","");
  vJson->SetValue("CTSRespHeader.TxAmt","");
  vJson->SetValue("CTSRespHeader.Contacter","");

  AddXMLParam("command", "9000");
  AddXMLParam("operate", "011013");
  AddXMLParam("json", vJson->toString());

  QDateTime dt;
    QTime time;
    QDate data;
    dt.setTime(time.currentTime());
    dt.setDate(data.currentDate());
    QString currentDate = dt.toString("yyyy:MM:dd:hh:mm:ss");

  insertddclick(id,"011013",currentDate,"");
}


QString Query011012(Json *json)
{
	QSqlQuery uniQ;
	QString totalRecords,pageSize,nextPage,brand,topage,sql,cd;
	Json *vJson,*resultList,*item;
	int i;

	cd="%iberry%bin%";
	vjson=new Json();

	vJson->SetValue("CTSRespHeader.TranCode","011012");
  vJson->SetValue("CTSRespHeader.ResultCode","CTS0000");
  vJson->SetValue("CTSRespHeader.Channel","");
  vJson->SetValue("CTSRespHeader.MesgRefID","");
  vJson->SetValue("CTSRespHeader.OrigSender","");
  vJson->SetValue("CTSRespHeader.Userid","");
  vJson->SetValue("CTSRespHeader.Comment","");
  vJson->SetValue("CTSRespHeader.TxAccount","");
  vJson->SetValue("CTSRespHeader.TxAmt","");
  vJson->SetValue("CTSRespHeader.Contacter","");
  uniQ=QSqlQuery();
}

  

﻿#include <QCoreApplication>
#include"myint.h"
#include<QDebug>
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    MyInt value1(56),value2(131),value3(13);
    value3=value1+value2;
    qDebug()<<value3.GetValue();
    return a.exec();
}

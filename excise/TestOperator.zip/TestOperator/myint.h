﻿#ifndef MYINT_H
#define MYINT_H
//+,-,*,/
class MyInt
{
public:
    MyInt();
    MyInt(int inValue);

    int GetValue()const;
    void SetValue(const int inValue);
    MyInt& operator =(const MyInt& inMyInt);
    MyInt& operator +(MyInt& inMyInt) const;
protected:
    int value;
};

#endif // MYINT_H
